# Rational-expression functionality notes

## Blocking requirements for this batch

None. All three YAML lessons use the currently supported native schema, generators, graders, answer modes, work modes, and review policies.

The lesson design deliberately stays honest about what QuickMaths can presently verify:

- Questions whose correctness includes **excluded domain values** use multiple choice. `symbolic_expression` can compare formulas, but algebraic equivalence alone does not preserve holes in a rational function's domain.
- Factoring and cancellation explanations use required `capture_only` work. The current expression-step checker can verify equivalent formulas, but it does not track whether a canceled factor was nonzero or whether an original restriction was preserved.
- Questions with several excluded values do not request an unordered free-response set because there is no finite-set answer grader.

## Recommended before a future rational-equations lesson

A later `MATH_RAT_004` on rational equations and extraneous solutions would be substantially richer with the following additions.

### 1. Domain-aware rational-expression grader

Suggested authoring shape:

```yaml
answer:
  type: rational_expression
  value: "(x + 4)/(x - 3)"
  excluded_values:
    - "-2"
    - "3"
grading:
  method: rational_expression
  require_reduced_form: true
```

Desired behavior:

- compare the formulas on their allowed domain;
- compare the exact excluded-value set separately;
- reject an answer that loses or invents a hole;
- optionally require reduced or factored form when the prompt asks for simplification;
- accept algebraically equivalent ordering and notation.

### 2. Unordered finite-set grader

Suggested authoring shape:

```yaml
answer:
  type: finite_set
  values:
    - "-2"
    - "5"
grading:
  method: finite_set
```

Desired behavior:

- ignore answer order and duplicate entries;
- compare numeric or symbolic members with the existing math parser;
- support empty set, all real numbers, and a finite list of values;
- work for roots, excluded values, and multi-solution equations.

### 3. Rational-equation work checker

A dedicated work mode such as `rational_equation_steps` should:

- preserve the original denominator restrictions throughout the submission;
- allow clearing denominators by a least common denominator only under those restrictions;
- follow candidate solutions through the transformed equation;
- require checking candidates in the original equation;
- identify and label extraneous solutions rather than merely marking the final line wrong.

A structured response could pair each equation line with a restriction list, for example:

```yaml
work:
  mode: rational_equation_steps
  target_variable: x
  require_original_equation_check: true
  require_restrictions: true
```

These features are not prerequisites for the three lessons in this batch. They are the point where I would pause before authoring a rigorous rational-equations successor instead of reducing that lesson to multiple choice and unverified prose.
