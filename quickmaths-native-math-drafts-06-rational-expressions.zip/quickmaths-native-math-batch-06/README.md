# QuickMaths native Mathematics batch 06

This review package contains three native YAML lessons forming a rational-expression branch:

1. `MATH_RAT_001` — rational expressions and domain restrictions
2. `MATH_RAT_002` — multiplying and dividing rational expressions
3. `MATH_RAT_003` — adding and subtracting rational expressions

Nothing in this package has been written to GitHub. See `INTEGRATION_NOTES.txt` for the proposed graph and track update, `VALIDATION_REPORT.txt` for local validation results, and `FUNCTIONALITY_NOTES.md` for the exact engine capabilities recommended before a later rational-equations lesson.
