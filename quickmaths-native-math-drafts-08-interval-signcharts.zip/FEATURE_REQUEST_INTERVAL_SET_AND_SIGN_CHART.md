# Feature request: `interval_set` grader and `sign_chart_steps` checker

Batch 08 intentionally uses two new lesson-engine capabilities. The design below keeps the final answer as a string, uses the existing `ProblemTemplate.answer` and `ProblemInstance.expected_answer` fields, and uses the existing `UserResponse.structured_work_json` field for the sign chart. No arbitrary uploaded code is required.

## 1. `interval_set` final-answer grader

### Authoring shape

```yaml
answer:
  type: interval_set
  variable: x
  value: "(-inf, -2] U (5, inf)"
grading:
  method: interval_set
```

`answer.value` remains a normal renderable template string. `answer.variable` is copied to `ProblemInstance.variable` and identifies the variable used when accepting equivalent inequality-form answers. Generated native content may use placeholders such as `{a}` and `{b}`. After generation, `ProblemInstance.expected_answer` is the rendered interval string.

### Required accepted syntax

At minimum, accept:

- intervals: `(-inf, 3)`, `[-2, 5]`, `[4, inf)`;
- unions: `(-inf, -2] U (5, inf)` and the Unicode union symbol `∪`;
- singleton intervals: `[3, 3]`;
- empty-set forms: `empty set`, `empty`, `{}`, and `∅`;
- all-real forms: `(-inf, inf)`, `all real numbers`, and `R`;
- common equivalent inequalities: `x < 3`, `x >= -2`, `-1 < x <= 4`, `x != 5`, and expressions joined by `or`.

Infinity must always be open. Reject malformed intervals, reversed endpoints, and variable-dependent endpoints other than the declared target variable's solved boundaries.

### Canonical comparison

Parse both expected and learner answers into a normalized union of real intervals and singleton points. Then:

1. sort components by lower endpoint;
2. merge overlapping intervals;
3. merge touching intervals when the union includes the touching point;
4. preserve a missing point when both touching endpoints are open;
5. compare endpoint values with the existing symbolic/numeric math parser;
6. compare the normalized sets, not their text spelling.

Python can use SymPy `Interval`, `FiniteSet`, `Union`, and symmetric difference. The browser can normalize an array of `{lower, upper, lowerClosed, upperClosed}` components and compare constant endpoints numerically using the existing expression evaluator. Endpoints in these lessons are integers, but the grader should also support fractions, `sqrt(...)`, `pi`, and `e`.

### Code touchpoints

- `quickmaths/config.py`: add `interval_set` to supported graders.
- `quickmaths/math_syntax.py`: add `parse_interval_set` and `interval_set_equal`.
- `quickmaths/grading.py`: dispatch `interval_set`.
- `quickmaths/validation.py`: validate/self-grade interval answers.
- `docs/challenge-core.js`: add the browser parser, normalizer, comparator, and grader dispatch.
- `schemas/skill.schema.json`, `docs/agent-manifest.json`, authoring guide, and tests: advertise the new type.

## 2. Recursive rendering for sign-chart metadata

Generated sign charts need rendered values inside nested `work.sign_chart` strings. Extend native generation so strings inside `work.sign_chart` are rendered with the same trusted template renderer used for prompts and expected answers.

Example authored metadata:

```yaml
work:
  mode: sign_chart_steps
  target_variable: x
  sign_chart:
    expression: "(x - {a})/(x - {b})"
    critical_points:
      - value: "{a}"
        kind: zero
        multiplicity: 1
        factor: "x - {a}"
```

After generation, the instance must contain literal rendered strings such as `x - 2`, `x - 5`, and values `2`, `5`.

Apply recursive rendering only to trusted native templates. Uploaded lesson sets remain fixed data and do not gain executable template expressions.

Touchpoints:

- `quickmaths/problem_generator.py`: deep-render `template.work` before constructing `ProblemInstance`.
- `docs/challenge-core.js`: deep-render native `work` metadata in `generateNativeProblem`.
- export tests: ensure fixed exported variants contain no unresolved `{...}` placeholders.

## 3. `sign_chart_steps` work checker

### Authoring shape

```yaml
work:
  mode: sign_chart_steps
  prompt: "Factor, list critical points, complete the sign chart, and give the interval solution."
  target_variable: x
  sign_chart:
    expression_kind: rational
    expression: "(x - {a})/(x - {b})"
    relation: ">="
    expected_factorization: "(x - {a})/(x - {b})"
    reduced_expression: "(x - {a})/(x - {b})"
    require_factorization: false
    critical_points:
      - value: "{a}"
        kind: zero
        multiplicity: 1
        factor: "x - {a}"
      - value: "{b}"
        kind: undefined
        multiplicity: 1
        factor: "x - {b}"
    require_test_values: true
    require_interval_signs: true
    require_endpoint_decisions: true
    require_final_answer_match: true
review_policy:
  work_review: auto
```

Supported `expression_kind` values:

- `polynomial`
- `rational`

Supported critical-point kinds:

- `zero`: the expression is defined and equals zero;
- `undefined`: an uncanceled denominator zero or pole;
- `hole`: an original denominator zero removed from the reduced formula but still excluded from the domain.

`multiplicity` is a positive integer. Odd multiplicity changes sign; even multiplicity preserves sign. A `hole` is always excluded and normally preserves the sign when the canceled numerator and denominator multiplicities match.

### Learner response shape

Use `UserResponse.structured_work_json` instead of trying to parse prose:

```json
{
  "factorization": "(x - 2)/(x - 5)",
  "critical_points": [
    {"value": "2", "kind": "zero"},
    {"value": "5", "kind": "undefined"}
  ],
  "intervals": [
    {"lower": null, "upper": "2", "test_value": "0", "sign": "positive", "selected": true},
    {"lower": "2", "upper": "5", "test_value": "3", "sign": "negative", "selected": false},
    {"lower": "5", "upper": null, "test_value": "6", "sign": "positive", "selected": true}
  ],
  "endpoints": [
    {"value": "2", "included": true},
    {"value": "5", "included": false}
  ]
}
```

The ordinary final-answer field still contains the learner's interval notation. Do not duplicate the final answer inside `structured_work_json`.

### Checker algorithm

1. Parse and validate the expected expression, relation, and critical-point metadata.
2. If factorization is required, compare the learner factorization with `expected_factorization`:
   - polynomial: symbolic equivalence plus a factored-form structural check;
   - rational: domain-aware rational equivalence, preserving exclusions and canceled holes.
3. Compare learner critical points symbolically and without regard to entry order.
4. Require exact classification as `zero`, `undefined`, or `hole`.
5. Sort the critical points and construct every open interval between them, including both unbounded intervals.
6. Validate each learner test value:
   - it lies strictly inside the intended interval;
   - the expression is defined there;
   - its evaluated sign agrees with the learner's sign selection.
7. Independently compute the expected sign on every interval using a deterministic safe test value. Never trust the learner's test value as the source of truth.
8. Check interval selection against the requested relation.
9. Check endpoints:
   - include a `zero` only for `<=` or `>=`;
   - exclude `zero` for `<` or `>`;
   - always exclude `undefined` and `hole` points.
10. Convert the learner-selected intervals plus included zeros to a set and compare it with both the final answer and the authored `interval_set` answer.
11. Return `correct`, `incorrect`, `incomplete`, or `uncertain` with targeted diagnostics.

### Suggested diagnostic payload

Adding an optional `details` object to `WorkCheckResult` makes the UI much better:

```json
{
  "factorization": {"status": "correct"},
  "critical_points": [{"value": "5", "status": "misclassified", "expected_kind": "undefined"}],
  "intervals": [{"index": 2, "status": "incorrect_sign", "expected": "negative"}],
  "endpoints": [{"value": "5", "status": "must_be_excluded"}],
  "final_set": {"status": "incorrect"}
}
```

The checker can work without this field by returning messages, but structured diagnostics allow row-level highlighting.

### Browser UI

For `sign_chart_steps`, render a structured editor rather than a large textarea:

1. optional factorization input;
2. add/remove critical-point rows with value and type;
3. automatically sorted interval rows after critical points are entered;
4. test-value input and sign selector for each interval;
5. selected-interval checkbox;
6. include/exclude choice for every finite critical point;
7. the normal final-answer input for interval notation.

Persist this editor in the test draft and backups as `structuredWorkJson`. Preserve the existing text `work` field as a fallback/export summary, but grade the structured payload.

### Validation rules

Reject authored sign charts when:

- the relation is not `<`, `<=`, `>`, or `>=`;
- critical-point values are duplicated or not ordered after rendering;
- multiplicity is not a positive integer;
- a `zero` is undefined in the authored expression;
- an `undefined` point is not a denominator zero;
- a `hole` remains undefined in `reduced_expression`;
- `expected_factorization` is not equivalent to `expression`;
- `reduced_expression` is not equivalent on the allowed domain;
- the authored interval answer disagrees with the computed sign chart;
- any nested native template remains unresolved after generation.

### Code touchpoints

- `quickmaths/validation.py`: add mode and authoring checks.
- `quickmaths/work_checker.py`: add `_check_sign_chart_steps`.
- `quickmaths/models.py`: optionally add `details` to `WorkCheckResult`; `structured_work_json` already exists on `UserResponse`.
- `docs/challenge-core.js`: sanitize/persist structured sign-chart responses and implement the browser checker.
- `docs/challenge.js`: render the sign-chart editor and result diagnostics.
- `docs/lesson-creator.js`: optional author UI after the engine works; native YAML can ship first.
- schema, manifest, guide, Python tests, and browser tests: add the new work mode.

## 4. Minimum test matrix

`interval_set` tests:

- equivalent unions in a different order;
- touching intervals that should merge and open-open points that must remain missing;
- singleton intervals;
- empty and all-real sets;
- strict versus inclusive boundaries;
- infinities forced open;
- fractions and radicals as endpoints;
- inequality-form learner answers.

`sign_chart_steps` tests:

- two simple polynomial roots;
- an even-multiplicity root;
- three simple roots;
- no real critical points;
- numerator zero versus denominator pole;
- an even-multiplicity denominator pole;
- a canceled hole that splits a selected interval without changing sign;
- a comparison that must first be moved to zero;
- an empty rational-inequality solution;
- malformed or incomplete structured work;
- final interval correct but chart incorrect, and chart correct but final interval incorrect.

Machine-readable acceptance examples are included in `FEATURE_TEST_VECTORS.json`.
