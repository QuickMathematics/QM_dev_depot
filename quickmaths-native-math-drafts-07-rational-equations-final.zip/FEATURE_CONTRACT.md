# Batch 07 lesson-engine contract

These lessons intentionally depend on the three rational-mathematics features proposed with batch 06.

## 1. Unordered finite-set answers

```yaml
answer:
  type: finite_set
  values:
    - "-2"
    - "5"
grading:
  method: finite_set
```

Required behavior:
- render every member template independently;
- compare members symbolically and without regard to order;
- ignore duplicate learner entries;
- interpret `values: []` as the empty real solution set;
- accept common learner forms such as `{ -2, 5 }`, `-2 or 5`, and equivalent structured input.

## 2. Domain-aware rational-expression answers

```yaml
answer:
  type: rational_expression
  value: "(x + 4)/(x - 3)"
  excluded_values:
    - "-2"
    - "3"
grading:
  method: rational_expression
  require_reduced_form: true
```

Required behavior:
- compare formulas on the allowed domain;
- compare the exact excluded-value set separately and without regard to order;
- preserve removable holes after factors cancel;
- when `require_reduced_form` is true, reject an answer that leaves a cancelable common factor.

## 3. Restriction-aware rational-equation work

```yaml
work:
  mode: rational_equation_steps
  prompt: "..."
  target_variable: x
  require_original_equation_check: true
  require_restrictions: true
review_policy:
  work_review: auto
```

Required behavior:
- capture and retain the original denominator restrictions;
- permit clearing denominators only under those restrictions;
- follow all candidates produced by the transformed equation;
- require explicit checks in the original equation when `require_original_equation_check` is true;
- distinguish valid, excluded, extraneous, repeated, and non-real candidates;
- compare the final valid-candidate set with the `finite_set` answer.

No additional engine feature is required for this batch.

A future rational-inequalities lesson would benefit from an `interval_set` grader supporting unions, open/closed endpoints, and sign-chart work. That feature is not used here.
