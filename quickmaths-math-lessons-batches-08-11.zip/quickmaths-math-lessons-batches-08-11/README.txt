QuickMaths native Mathematics lessons — batches 08 through 11

This archive contains the 12 complete YAML lesson files authored in:
- Batch 08: interval notation and sign charts
- Batch 09: logarithms
- Batch 10: trigonometry
- Batch 11: advanced trigonometry

The lesson YAML bodies are copied byte-for-byte from the previously delivered artifacts.
Copy the YAML files from:
  content/math/algebra_foundations/skills/
into the same path in a QuickMaths checkout.

This archive intentionally does not include track.yaml, browser-test patches, feature requests,
or integration notes. It is a lesson-file-only bundle.
