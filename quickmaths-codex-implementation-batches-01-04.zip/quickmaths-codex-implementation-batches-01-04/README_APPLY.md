# QuickMaths native Mathematics implementation bundle — batches 01–04

This ZIP contains only the completed implementation artifacts requested for consolidation. It does not contain an additional lesson batch.

## Included

- `content/math/algebra_foundations/skills/`: all 12 complete lesson YAMLs from batches 01–04. Their bytes are copied directly from the four previously delivered validated ZIPs; none of the lesson bodies were regenerated, reformatted, or revised.
- `content/math/algebra_foundations/track.yaml`: complete replacement track integrating all 12 lessons and adding `MATH_QUAD_005` as the completed branch exit.
- `patches/0001-*.patch` through `0007-*.patch`: one exact unified diff per recommended native-curriculum fix, followed by the track integration patch.
- `patches/ALL_RECOMMENDED_FIXES_AND_TRACK.patch`: the same seven patches concatenated in application order.
- `replacements/`: complete replacement YAMLs for `MATH_ALG_007` and `MATH_SYS_001`, the two larger native fixes.
- `provenance/`: original batch validation reports, source-file hashes, reviewed base commit, and expected Git blob IDs.
- `SHA256SUMS.txt`: SHA-256 for every artifact in the bundle except the checksum file itself.

## Apply from the QuickMaths repository root

Copy the new lesson files without rewriting them, then apply the combined patch:

```bash
cp /path/to/bundle/content/math/algebra_foundations/skills/*.yaml content/math/algebra_foundations/skills/
git apply /path/to/bundle/patches/ALL_RECOMMENDED_FIXES_AND_TRACK.patch
```

The combined patch modifies these existing files:

- `MATH_ARITH_004_multiplying_dividing_fractions.yaml`
- `MATH_GRAPH_004_slope_intercept_form.yaml`
- `MATH_ALG_007_inequality_sign_reversal.yaml`
- `MATH_SYS_001_systems_of_equations.yaml`
- `MATH_GRAPH_001_coordinate_plane.yaml`
- `MATH_GRAPH_006_writing_equations_of_lines.yaml`
- `track.yaml`

If local edits make the two large patch hunks inconvenient, use the complete files under `replacements/` for `MATH_ALG_007` and `MATH_SYS_001`, and apply the remaining split patches individually.

Then run the project validation and export pipeline:

```bash
python -m quickmaths.cli validate-content --strict-warnings
python scripts/export_web_curriculum.py
python -m pytest -q
node --test docs/*.test.js
node --test community-worker/src/*.test.js
```

The existing-file patches were prepared against the unchanged native Mathematics blobs reviewed at commit `dbafb2c94bc51df00dfc82e65ed89cf3a7cd20db`. Exact original blob IDs are recorded in `provenance/BASE_BLOBS.txt`.
