# Package inventory

- Pack: `PACK_PROGRAMMING_FUNDAMENTALS` version `1.2.0`
- Lessons: 28
- Questions: 280
- New lessons: 3
- Mathematics bridges: 12
- Lesson-set size: 463,588 bytes

## New lessons

- `CUSTOM_PROG_026` — Type hints, dataclasses, and explicit contracts: 10 questions, 4 examples, 3 applications
- `CUSTOM_PROG_027` — Iterators, generators, and lazy pipelines: 10 questions, 4 examples, 3 applications
- `CUSTOM_PROG_028` — Recursion, trees, and memoization: 10 questions, 4 examples, 3 applications
