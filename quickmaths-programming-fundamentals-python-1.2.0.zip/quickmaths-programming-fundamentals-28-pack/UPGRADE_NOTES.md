# Upgrade notes: 1.1.0 to 1.2.0

- Preserves `CUSTOM_PROG_001` through `CUSTOM_PROG_025` without modifying their lesson objects or question banks.
- Appends `CUSTOM_PROG_026`, `CUSTOM_PROG_027`, and `CUSTOM_PROG_028`.
- Changes the track exit from `CUSTOM_PROG_025` to `CUSTOM_PROG_028`.
- Updates pack, subject, and track descriptions to include type contracts, lazy iteration, and recursion.
- Bumps the pack and metadata version to `1.2.0`.
- Adds Mathematics bridges to `MATH_FUNC_001`, `MATH_SEQ_001`, and `MATH_EXP_002`.

QuickMaths currently treats an installed pack ID as already installed rather than performing an in-place package upgrade. For a clean review, validate version 1.2.0 in a profile where version 1.1.0 is not installed, or uninstall/reload according to the app's existing content-management flow while preserving a full learner backup.
