# Programming Fundamentals with Python 1.2.0

This directory contains a complete QuickMaths schema-2.0 lesson set with 28 lessons and 280 fixed mastery questions.

## Files

- `lesson-set.json` — complete installable package
- `metadata.json` — proposed Lesson Depot metadata
- `new-lessons/` — the three appended lesson objects for focused review
- `depot-layout/` — ready-to-place Lesson Depot directory structure
- `CURRICULUM_MAP.md` — track and Mathematics bridge rationale
- `UPGRADE_NOTES.md` — changes from version 1.1.0
- `PRESERVATION_REPORT.txt` — hashes proving lessons 1–25 were preserved
- `VALIDATION_REPORT.txt` and `validation-summary.json` — structural and semantic checks
- `lesson-set-1.1.0-to-1.2.0.patch` — exact unified diff
- `PROGRAMMING_ENGINE_ENHANCEMENTS.md` — optional richer programming-assessment architecture
- `CHECKSUMS.sha256` — integrity manifest

Compatibility baseline: QuickMathematics/QuickMaths `c8af89e01d65d05168bbd1591a3849c042a32047`.

No new lesson-engine feature is required. The existing optional programming enhancements—formatted code blocks, structured trace work, and a sandboxed Python grader—would make future versions more interactive but are not dependencies for this package.
