# Programming Fundamentals with Python 1.2.0

## Track shape

```text
CUSTOM_PROG_001 → … → CUSTOM_PROG_024 → CUSTOM_PROG_025
                                              ↓
                                      CUSTOM_PROG_026
                                  Type hints and dataclasses
                                              ↓
                                      CUSTOM_PROG_027
                                  Iterators and generators
                                              ↓
                                      CUSTOM_PROG_028
                                  Recursion and tree data
```

Lessons 1–25 are unchanged from version 1.1.0. Version 1.2.0 appends a third stage focused on explicit contracts and nontrivial control of computation.

## New Mathematics bridges

| Programming lesson | Mathematics prerequisite | Rationale |
| --- | --- | --- |
| `CUSTOM_PROG_026` | `MATH_FUNC_001` Function notation and representations | Function annotations describe input/output mappings and make contracts explicit. |
| `CUSTOM_PROG_027` | `MATH_SEQ_001` Arithmetic sequences | Iterators and generators produce ordered terms one at a time and often model sequence rules. |
| `CUSTOM_PROG_028` | `MATH_EXP_002` Exponential functions and percent change | Branching recursion motivates exponential growth in work and the value of memoization. |

The existing 1.1.0 pack already bridges programming to integer operations, order of operations, substitution, functions, word-to-expression translation, percentages, coordinate pairs, sequences, and exponential growth.

## New lesson objectives

### 26. Type hints, dataclasses, and explicit contracts

Learners distinguish static annotations from runtime validation, annotate collection and optional types, use dataclasses for named records, avoid shared mutable defaults, validate invariants in `__post_init__`, and model immutable updates.

### 27. Iterators, generators, and lazy pipelines

Learners distinguish iterables from iterators, use `iter` and `next`, understand exhaustion and one-pass behavior, write generator functions with `yield`, compose lazy pipelines, and choose laziness for memory or early stopping rather than novelty.

### 28. Recursion, trees, and memoization

Learners design base and recursive cases, trace stack order, recognize nontermination, traverse recursive tree data, distinguish trees from cyclic graphs, and use memoization when a pure recursion repeats subproblems.
