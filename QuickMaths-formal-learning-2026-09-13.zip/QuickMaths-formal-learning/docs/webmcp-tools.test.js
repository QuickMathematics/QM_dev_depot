import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, statSync } from "node:fs";

import { DEFAULT_SUBJECT, LESSON_SET_FORMAT, createQuickMathsStore } from "./challenge-core.js";
import { buildToolDefinitions, registerWebMcpTools, TOOL_NAMES } from "./webmcp-tools.js";

test("WebMCP can stage Python lessons but exposes no silent code-execution tool", () => {
  assert.equal(TOOL_NAMES.some((name) => /run.*python|execute.*python|python.*run/i.test(name)), false);
  assert.equal(TOOL_NAMES.includes("stage_custom_lesson_set"), true);
  assert.equal(TOOL_NAMES.includes("stage_depot_lessons"), true);
});

const curriculum = JSON.parse(readFileSync(new URL("./curriculum-data.json", import.meta.url), "utf8"));
const agentManifest = JSON.parse(readFileSync(new URL("./agent-manifest.json", import.meta.url), "utf8"));
const authoringGuide = readFileSync(new URL("./CUSTOM_LESSON_SETS.md", import.meta.url), "utf8");
const learnerManual = readFileSync(new URL("./STUDENT_GUIDE.md", import.meta.url), "utf8");
const educatorManual = readFileSync(new URL("./EDUCATOR_GUIDE.md", import.meta.url), "utf8");
const geographyLessonSet = readFileSync(new URL("./lesson-depot/lessons/geography/1.0.0/lesson-set.json", import.meta.url), "utf8");

function createStore({ profile = true } = {}) {
  const values = new Map();
  const store = createQuickMathsStore({
    storage: {
      getItem(key) { return values.get(key) ?? null; },
      setItem(key, value) { values.set(key, String(value)); },
    },
    curriculum,
    now: () => new Date("2026-09-01T09:42:00.000Z"),
  });
  if (profile) store.createProfile("Agent Learner");
  return store;
}

function toolsFor(store) {
  return Object.fromEntries(buildToolDefinitions(store, agentManifest, null, null, authoringGuide, { learner: learnerManual, educator: educatorManual }).map((tool) => [tool.name, tool]));
}

function nativeImprovement(store) {
  const source = structuredClone(store.skillsById.MATH_ARITH_001);
  return {
    format: LESSON_SET_FORMAT, schema_version: "2.0", mode: "override",
    id: "PACK_IMPROVE_MATH_ARITH_001", name: "Improved integer operations",
    description: "A reversible native lesson improvement.", author: "Agent author", version: "1.0.0",
    subject: { ...structuredClone(DEFAULT_SUBJECT), short_name: DEFAULT_SUBJECT.shortName },
    track: { skills: [source.id] },
    skills: [{ ...source, name: "Integer operations · improved" }],
  };
}

test("browser shell exposes Settings, Lesson Depot, map zoom, prompt copy, and persistent Agent Studio controls", () => {
  const html = readFileSync(new URL("./index.html", import.meta.url), "utf8");
  const js = readFileSync(new URL("./challenge.js", import.meta.url), "utf8");
  const agentPrompts = readFileSync(new URL("./agent-prompts.js", import.meta.url), "utf8");
  const css = readFileSync(new URL("./challenge.css", import.meta.url), "utf8");
  const community = readFileSync(new URL("./github-community.js", import.meta.url), "utf8");
  const communityCallback = readFileSync(new URL("./community-auth.html", import.meta.url), "utf8");
  const githubSyncSource = readFileSync(new URL("./github-sync.js", import.meta.url), "utf8");
  const studentGuideSource = readFileSync(new URL("./STUDENT_GUIDE.md", import.meta.url), "utf8");
  const studentPdfUrl = new URL("./QuickMaths-Student-Guide.pdf", import.meta.url);
  const educatorGuideSource = readFileSync(new URL("./EDUCATOR_GUIDE.md", import.meta.url), "utf8");
  const educatorPdfUrl = new URL("./QuickMaths-Educator-Guide.pdf", import.meta.url);
  assert.match(html, /data-route="settings"/);
  assert.match(html, /data-route="depot"/);
  assert.match(js, /renderLessonDepot/);
  assert.match(js, /renderLessonHubTabs/);
  assert.match(js, /button\.closest\("\.mobile-nav"\) && route === "creator"/);
  assert.doesNotMatch(html, /class="mode-switch"|id="replay-tutorial"/);
  assert.match(js, /data-action="map-zoom-in"/);
  assert.doesNotMatch(js, /data-map-scope=/);
  assert.match(js, /map-subject-lane/);
  assert.match(js, /map-node-status-dot/);
  assert.match(js, /What your proof must cover/);
  assert.match(js, /workResponsePlaceholder/);
  assert.match(js, /review-question-select/);
  assert.match(js, /attempt\.results\.findIndex\(\(item\) => item\.questionId === result\.questionId\) \+ 1/);
  assert.match(js, /resultReviewGuide/);
  assert.match(js, /MAP_ZOOM_MIN = 0\.1/);
  assert.doesNotMatch(js, /Math\.min\(5/);
  assert.match(js, /authored scenarios are included/);
  assert.match(js, /addEventListener\("pointermove"/);
  assert.match(js, /startDistance/);
  assert.match(js, /agentHandoffMarkup\(snapshot, \{ compact: true \}\)/);
  assert.match(html, /id="welcome-lesson-count">…<\/strong> connected lessons/);
  assert.doesNotMatch(html, /<strong>25<\/strong> connected skills/);
  assert.match(html, /Local-first mastery learning/);
  assert.match(html, /id="welcome-storage-restore"/);
  assert.match(html, /id="welcome-educator-path"/);
  assert.match(html, /id="educator-welcome-root"/);
  assert.match(html, /id="agent-welcome-root"/);
  assert.match(html, /id="agent-handoff-root"/);
  assert.match(html, /QuickMaths-Student-Guide\.pdf/);
  assert.match(html, /QuickMaths-Educator-Guide\.pdf/);
  assert.doesNotMatch(html, /educator-agent-manifest\.json/);
  assert.match(html, /id="welcome-curriculum-url-form"/);
  assert.match(html, /data-route="curriculum"/);
  assert.match(css, /\.welcome-storage-restore \{[^}]*border-radius: 14px;[^}]*background:/);
  assert.match(css, /\.welcome-storage-restore > summary strong \{ font-size: 15px/);
  assert.match(js, /QuickMaths is for learning and practice/);
  assert.doesNotMatch(agentPrompts, /get_educator_agent_manifest/);
  assert.match(js, /return agentStarterPrompt\(\)/);
  assert.match(js, /data-action="copy-current-agent-prompt"/);
  assert.match(js, /data-action="dismiss-educator-welcome"/);
  assert.match(js, /completeEducatorWelcome/);
  assert.doesNotMatch(js, /Attempts per lesson/);
  assert.match(html, /id="app-shell" class="app-shell agent-collapsed"/);
  assert.match(html, /id="agent-dock" class="agent-dock is-closed"/);
  assert.match(js, /Open in ChatGPT \/ Codex/);
  assert.match(js, /Download backup/);
  assert.match(js, /Set up GitHub storage/);
  assert.match(js, /First-time agent-in-the-loop setup must be completed on a computer/);
  assert.match(js, /Never end Windows, security, driver, or remote-session processes/);
  assert.match(js, /install and approve the required packs yourself first/);
  assert.match(css, /\.mobile-remote-setup/);
  assert.doesNotMatch(html, /QuickMaths turns \d+ connected lessons across \d+ installed subjects/);
  assert.match(js, /snapshot\.curriculum\.allSkills\.length/);
  assert.match(agentPrompts, /get_agent_guide with section/);
  assert.doesNotMatch(agentPrompts, /get_educator_agent_manifest/);
  assert.match(agentPrompts, /codex:\/\/threads\/new/);
  assert.match(agentPrompts, /browserUrl/);
  assert.doesNotMatch(agentPrompts, /never ask me to paste a token/);
  assert.match(js, /hasPriorAgentActivity/);
  assert.match(js, /agentActivityAt/);
  assert.match(js, /visual: "depot"/);
  assert.match(js, /GitHub Bridge/);
  assert.match(js, /Manage GitHub storage/);
  assert.match(js, /confirmPermanentDeletion/);
  assert.match(js, /function requestAppConfirmation/);
  assert.match(js, /openWorkspaceMerge/);
  assert.match(js, /githubSync\.applyMerge/);
  assert.doesNotMatch(js, /window\.confirm\("Replace the GitHub learner checkpoint/);
  assert.match(js, /learnerBridgeStartupAction/);
  assert.match(js, /opens the global merge window/);
  assert.match(js, /void recoverEstablishedLearnerConflict\(\)/);
  assert.match(js, /githubSync\.prepareMerge/);

  assert.match(css, /\.bridge-source-dialog/);
  assert.match(githubSyncSource, /await syncLearnerNow\(\{ quiet: true \}\)/);
  assert.match(js, /Are you absolutely sure/);
  assert.match(js, /clearRemoteWorkspace/);
  assert.match(js, /resumeAfterClear/);
  assert.match(js, /storage connection and token were kept/);
  assert.match(css, /\.workspace-storage-manager/);
  assert.match(css, /\.tour-depot-preview/);
  assert.doesNotMatch(html, /id="subject-select"/);
  assert.match(js, /All installed fields/);
  assert.match(js, /last lesson you opened/);
  assert.match(js, /Native improvements are reversible from Settings without erasing progress/);
  assert.match(js, /Create \/ improve/);
  assert.match(css, /\.welcome-brand \{[^}]*"Times New Roman"/);
  assert.match(css, /\.sidebar-brand strong \{[^}]*"Times New Roman"/);
  assert.match(css, /touch-action: none/);
  assert.doesNotMatch(css, /\.map-scope-control/);
  assert.match(css, /\.map-edges \.is-cross-subject/);
  assert.match(css, /\.map-node \.map-node-subject-accent/);
  assert.match(css, /\.studio-student-preview/);
  assert.match(css, /\.lesson-hub-tabs/);
  assert.match(css, /\.studio-question-roadmap/);
  assert.match(css, /\.studio-response-picker/);
  assert.match(css, /\.studio-proof-anatomy/);
  assert.match(css, /\.studio-proof-contrast/);
  assert.match(css, /\.studio-native-picker/);
  assert.match(css, /\.studio-override-note/);
  assert.match(css, /tool-failed/);
  assert.match(js, /restore-native-lessons/);
  assert.match(js, /Lesson sets and native improvements/);
  assert.match(css, /\.studio-help\[aria-expanded="true"\]/);
  assert.match(css, /\.result-review-guide/);
  assert.match(css, /\.map-layout \{[^}]*align-items: start;[^}]*min-height: 0;/);
  assert.match(css, /\.map-scroll \{[^}]*width: 100%;[^}]*height: clamp\(420px, 62svh, 560px\);[^}]*contain: layout paint;/);
  assert.match(css, /height: clamp\(300px, 60svh, 540px\); max-height: none; contain: layout paint/);
  assert.match(js, /scroller\.scrollLeft = gesture\.startScrollLeft - deltaX;\s+scroller\.scrollTop = gesture\.startScrollTop - deltaY;/);
  assert.match(js, /pressedSkillId/);
  assert.match(js, /store\.selectMapSkill\(finishedGesture\.pressedSkillId\)/);
  assert.match(js, /data-map-viewport-key/);
  assert.match(js, /const worldLeft = previousViewport\.viewMinX \+ previousViewport\.scrollLeft \/ previousViewport\.zoom;/);
  assert.match(js, /addEventListener\("wheel"/);
  assert.match(js, /passive: false/);
  assert.match(js, /map-hint-desktop/);
  assert.match(js, /map-hint-touch/);
  assert.match(js, /data-action=\"toggle-plan-mode\"/);
  assert.doesNotMatch(js, /data-action=\"toggle-plan-view\"/); // Read-only plan view follows the active plan, not a separate toggle.
  assert.match(js, /Plan view · read only/);
  assert.match(js, /class=\"map-selection-marquee\"/);
  assert.match(js, /event\.ctrlKey \|\| event\.metaKey/);
  assert.match(js, /navigator\.vibrate/);
  assert.match(js, /mode: "plan-empty-touch"/);
  assert.match(js, /Hold empty space to clear the selection/);
  assert.match(js, /map-plan-path-form/);
  assert.match(js, /map-plan-annotation-form/);
  assert.match(js, /Select multiple nodes to create a custom path\./);
  assert.match(js, /data-action="plan-open-annotation"/);
  assert.match(js, /data-action="plan-open-path"/);
  assert.match(js, /data-action="plan-toggle-hidden"/);
  assert.match(js, /data-action="plan-hide-selected"/);
  assert.match(js, /Field bands are guides/);
  assert.match(css, /\.map-node\.is-plan-hidden/);
  assert.match(js, /data-plan-comment=/);
  assert.match(js, /updateMapPlanAnnotationPosition/);
  assert.match(css, /\.map-node-plan-outline/);
  assert.match(css, /\.map-plan-connection/);
  assert.match(css, /\.map-plan-actionbar/);
  assert.match(css, /\.map-plan-comment-link/);
  assert.match(css, /\.map-layout\.is-plan-mode \{ grid-template-columns: minmax\(0, 1fr\); \}/);
  assert.match(css, /\.map-plan-panel\.is-composer-open \{ position: fixed;/);
  assert.match(css, /\.agent-dock\.is-closed/);
  assert.match(css, /\.app-shell\.is-educator/);
  assert.match(css, /\.educator-welcome-backdrop/);
  assert.match(css, /\.educator-prompt-card/);
  assert.match(css, /\.curriculum-editor-grid/);
  assert.match(css, /\.app-shell\.agent-collapsed \.agent-toggle/);
  assert.match(js, /createGitHubSyncController/);
  assert.match(js, /id = "github-sync-form"/);
  assert.match(js, /id: "welcome-github-sync-form", landing: true/);
  assert.match(js, /Connect and load my workspace/);
  assert.match(js, /uploads the complete QuickMaths workspace in this browser/);
  assert.match(js, /repository must be private/);
  assert.match(js, /Paste your fine-grained GitHub token/);
  assert.match(js, /autocomplete="new-password"/);
  assert.match(js, /captureBridgeFormDraft/);
  assert.match(js, /restoreBridgeFormDraft/);
  assert.match(js, /restoreOnly: true/);
  assert.match(js, /Existing mastery is reused only when the curriculum's student name matches/);
  assert.match(js, /if \(studioHelp\) \{/);
  assert.doesNotMatch(js, /studioHelp && currentSnapshot\?\.ui\.route === "creator"/);
  assert.match(js, /closeAgentStudio\(\{ focusToggle: false \}\);/);
  assert.doesNotMatch(js, /Repository Contents: read and write/);
  assert.match(js, /\.\/agent-bridge\.html/);
  assert.doesNotMatch(js, /data-depot-action="community-upvote"/);
  assert.match(js, /community-reaction-groups/);
  assert.match(js, /renderGroupedReactions\(comment, \{ comment: true \}\)/);
  assert.doesNotMatch(js, /community-comment-upvote/);
  assert.match(js, /data-depot-action="community-react"/);
  assert.match(js, /id="community-comment-form"/);
  assert.match(css, /\.depot-community-panel/);
  assert.match(community, /addReaction/);
  assert.match(community, /removeReaction/);
  assert.match(community, /depot-reactions\.js/);
  assert.doesNotMatch(community, /addUpvote|removeUpvote/);
  assert.match(community, /addDiscussionComment/);
  assert.match(community, /quickmaths\.github-community\.credential\.session/);
  assert.doesNotMatch(community, /client_secret/);
  assert.match(communityCallback, /community-auth\.js/);
  assert.match(studentGuideSource, /complete learner-facing product/i);
  assert.match(studentGuideSource, /Learner WebMCP starting command: `get_agent_guide`/);
  assert.ok(statSync(studentPdfUrl).size > 50_000);
  assert.equal(readFileSync(studentPdfUrl).subarray(0, 5).toString(), "%PDF-");
  assert.match(educatorGuideSource, /complete visible product: educator setup, every educator control/i);
  assert.match(educatorGuideSource, /get_agent_guide/);
  assert.ok(statSync(educatorPdfUrl).size > 50_000);
  assert.equal(readFileSync(educatorPdfUrl).subarray(0, 5).toString(), "%PDF-");
});

test("challenge documentation lists every advertised page tool and the dated delta evidence", () => {
  const challenge = readFileSync(new URL("../WEBMCP_CHALLENGE.md", import.meta.url), "utf8");
  for (const name of TOOL_NAMES) assert.equal(challenge.includes(`| \`${name}\` |`), true, `${name} is missing from the challenge tool table`);
  assert.match(challenge, /Challenge-period delta/);
  assert.match(challenge, /4c173a7/);
  assert.match(challenge, /80738f6/);
  assert.match(challenge, /compare\/4c173a7\.\.\.main/);
});

test("agent bridge ships as a dedicated top-level WebMCP workspace", () => {
  const html = readFileSync(new URL("./agent-bridge.html", import.meta.url), "utf8");
  const js = readFileSync(new URL("./agent-bridge.js", import.meta.url), "utf8");
  assert.match(html, /id="connection-form"/);
  assert.match(html, /Fine-grained storage token/);
  assert.match(html, /placeholder="Paste your fine-grained GitHub token"/);
  assert.match(html, /autocomplete="new-password"/);
  assert.doesNotMatch(html, /placeholder="Contents: read and write"/);
  assert.match(html, /id="pull-button"/);
  assert.match(html, /id="push-button"/);
  assert.match(js, /registerWebMcpTools/);
  assert.match(js, /registerBridgeWebMcpTools/);
  assert.match(js, /sync\.resume/);
  assert.match(js, /quickmaths\.agent-bridge/);
  assert.match(js, /resolveLocalBridgeCapability/);
  assert.match(js, /local-git-transport/);
});

test("registers all thirty-five tools once with the WebMCP document context", async () => {
  const registered = [];
  const result = await registerWebMcpTools(createStore(), {
    async registerTool(definition) { registered.push(definition); },
  }, agentManifest, null, null, authoringGuide, { learner: learnerManual, educator: educatorManual });
  assert.equal(result.available, true);
  assert.equal(TOOL_NAMES.length, 35);
  assert.deepEqual(result.registered, TOOL_NAMES);
  assert.deepEqual(result.failures, []);
  assert.deepEqual(registered.map(({ name }) => name), TOOL_NAMES);
  assert.ok(registered.every(({ description }) => description.length > 0));
  assert.ok(registered.every(({ inputSchema }) => inputSchema.additionalProperties === false));
});

test("degrades cleanly when WebMCP is unavailable", async () => {
  const result = await registerWebMcpTools(createStore(), undefined);
  assert.deepEqual(result, { available: false, registered: [], failures: [], error: null });
});

test("agent guide exposes operating, backup, and custom-content policy without learner answers", async () => {
  const store = createStore();
  store.startTest("MATH_ARITH_001");
  const tools = toolsFor(store);
  const summary = await tools.get_agent_guide.execute({});
  const bridge = await tools.get_agent_guide.execute({ section: "bridge" });
  const custom = await tools.get_agent_guide.execute({ section: "custom_content" });
  const planning = await tools.get_agent_guide.execute({ section: "planning" });
  const backup = await tools.get_agent_guide.execute({ section: "backup" });
  const full = await tools.get_agent_guide.execute({ section: "all" });
  const serialized = JSON.stringify(full);
  assert.equal(summary.section, "summary");
  assert.equal(summary.guide.app, "QuickMaths Web");
  assert.equal(summary.guide.app_version, agentManifest.app_version);
  assert.match(summary.guide.browser_boundary, /ChatGPT or Codex in-app browser/);
  assert.match(summary.guide.browser_boundary, /already-open in-app QuickMaths tab/);
  assert.match(summary.guide.mobile_boundary, /First-time agent-in-the-loop setup must be completed on a computer/);
  assert.match(summary.guide.credential_handoff, /Never ask the human to paste a token into chat/);
  assert.match(summary.guide.source_fallback, /github\.com\/QuickMathematics\/QuickMaths/);
  assert.match(summary.guide.source_fallback, /fallback source of truth/);
  assert.deepEqual(summary.guide.recommended_sequence, ["get_app_state", "get_progress_summary", "get_learning_context"]);
  assert.equal(summary.guide.tools.length, TOOL_NAMES.length);
  assert.equal(summary.guide.active_role_guidance.role, "learner");
  assert.match(summary.guide.active_role_guidance.response_style.join(" "), /lightly quirky/);
  assert.match(summary.guide.remote_mobile.first_setup, /computer that will remain online/);
  assert.match(summary.guide.remote_mobile.package_boundary, /human must approve each installation/);
  assert.match(summary.guide.remote_mobile.host_readiness.join(" "), /Sleep to Never/);
  assert.match(summary.guide.default_curriculum_plan, /Keep one known lesson as my starting anchor/);
  assert.match(summary.guide.default_curriculum_plan, /separate colored Python and Mathematics paths/);
  assert.ok(JSON.stringify(summary).length < JSON.stringify(full).length / 2);
  assert.match(bridge.guide.github_bridge.setup_recommendation, /persistent Workspace Storage/);
  assert.match(bridge.guide.github_bridge.setup_recommendation, /Never ask them to paste the token into chat/);
  assert.match(custom.guide.github_community.setup_recommendation, /separate from Workspace Storage/);
  assert.equal(custom.guide.custom_lesson_sets.format, "quickmaths.lesson-set");
  assert.equal(custom.guide.lesson_depot.route, "depot");
  assert.equal(planning.guide.tools.includes("create_map_plan_path"), true);
  assert.match(planning.guide.state_model.canonical_boundary, /canonical.*map/);
  assert.equal(planning.guide.default_curriculum_plan, summary.guide.default_curriculum_plan);
  assert.equal(backup.guide.backup_policy.recommend, true);
  assert.equal(full.guide.agent_policy.start.some((item) => item.includes("cross-device recovery")), true);
  assert.equal(full.guide.agent_policy.start.some((item) => item.includes("GitHub Community authorization")), true);
  assert.equal(serialized.includes("expected_answer"), false);
  assert.equal(serialized.includes("finalAnswer"), false);
  await assert.rejects(tools.get_agent_guide.execute({ section: "everything" }), /section must be one of/i);
});

test("agent can pull the lesson authoring guide by section through WebMCP", async () => {
  const tools = toolsFor(createStore());
  const summary = await tools.get_lesson_authoring_guide.execute({});
  const work = await tools.get_lesson_authoring_guide.execute({ section: "grading_and_work" });
  assert.equal(summary.ok, true);
  assert.match(summary.guide.markdown, /Agent Lesson Authoring Guide/);
  assert.match(work.guide.markdown, /Answer and shown-work modes/);
  assert.equal(work.guide.source_url, "./CUSTOM_LESSON_SETS.md");
  await assert.rejects(tools.get_lesson_authoring_guide.execute({ section: "secrets" }), /section must be one of/i);
});

test("agent can pull machine-readable learner and educator manuals by chapter", async () => {
  const learnerTools = toolsFor(createStore());
  const learnerIndex = await learnerTools.get_quickmaths_manual.execute({});
  const learnerAgentChapter = await learnerTools.get_quickmaths_manual.execute({ audience: "learner", section: "14" });
  assert.equal(learnerIndex.audience, "learner");
  assert.equal(learnerIndex.section, "summary");
  assert.equal(learnerIndex.manual.chapters.length, 18);
  assert.match(learnerAgentChapter.manual.markdown, /^## 14\. Learning with an agent/m);
  assert.doesNotMatch(learnerAgentChapter.manual.markdown, /^## 15\./m);

  const educatorStore = createStore({ profile: false });
  educatorStore.createProfile("Manual Educator", { role: "educator" });
  const educatorTools = toolsFor(educatorStore);
  const educatorIndex = await educatorTools.get_quickmaths_manual.execute({});
  const educatorWebMcpChapter = await educatorTools.get_quickmaths_manual.execute({ section: "11" });
  assert.equal(educatorIndex.audience, "educator");
  assert.equal(educatorIndex.manual.chapters.length, 16);
  assert.match(educatorWebMcpChapter.manual.markdown, /^## 11\. WebMCP educator integration/m);
  await assert.rejects(educatorTools.get_quickmaths_manual.execute({ section: "17" }), /not available in the educator manual/);
});

test("the unified guide routes fresh visitors without dumping a generic feature menu", async () => {
  const tools = toolsFor(createStore({ profile: false }));
  const summary = await tools.get_agent_guide.execute({ section: "summary" });
  assert.equal(summary.guide.runtime_context.workspace_fresh, true);
  assert.match(summary.guide.runtime_context.required_next_move, /learn or design a curriculum/);
  assert.match(summary.guide.onboarding.fresh_workspace.rule, /Do not respond with a generic numbered menu/);
  assert.match(summary.guide.onboarding.fresh_workspace.learner_path, /Restore existing private Workspace Storage before creating a profile/);
  assert.match(summary.guide.onboarding.fresh_workspace.educator_path, /visible Educator landing-page path/);
  assert.match(summary.guide.onboarding.fresh_workspace.educator_path, /create_curriculum/);
  assert.match(summary.guide.onboarding.fresh_workspace.storage_priority, /Strongly recommend private Workspace Storage/);
  assert.match(summary.guide.onboarding.fresh_workspace.community_follow_up, /optional and separate/);
  assert.equal(summary.guide.recommended_sequence, summary.guide.onboarding.fresh_workspace.agent_sequence);
});

test("educator WebMCP tools compose curricula and expose learner-visible supplemental guidance", async () => {
  const store = createStore({ profile: false });
  store.createProfile("Agent Educator", { role: "educator" });
  store.importLessonPack(geographyLessonSet);
  const tools = toolsFor(store);
  const educatorGuide = await tools.get_agent_guide.execute({ section: "educator" });
  assert.equal(educatorGuide.guide.runtime_context.active_profile_role, "educator");
  assert.match(educatorGuide.guide.browser_boundary, /external browser tab/);
  assert.match(educatorGuide.guide.credential_handoff, /Never ask the human to paste a token into chat/);
  assert.match(educatorGuide.guide.role_contract.documentation_pdf, /QuickMaths-Educator-Guide\.pdf/);
  assert.match(educatorGuide.guide.role_contract.start.join(" "), /sequential review queue/);
  assert.match(educatorGuide.guide.response_style.join(" "), /neutral, concise/);
  assert.equal(JSON.stringify(educatorGuide).includes("expected_answer"), false);
  const workspace = await tools.get_curriculum_workspace.execute({});
  assert.equal(workspace.active_curriculum.ownerProfileId, store.snapshot().activeProfile.id);
  assert.equal(workspace.installed_packs[0].enabled, true);

  const focused = await tools.set_curriculum_native_lessons_enabled.execute({ enabled: false });
  assert.equal(focused.enabled, false);
  assert.equal(store.snapshot().activeCurriculum.includeNativeLessons, false);
  assert.ok(store.snapshot().curriculum.allSkills.filter((skill) => skill.subjectId === "SUBJECT_MATH").length < 84);
  await tools.set_curriculum_native_lessons_enabled.execute({ enabled: true });
  await tools.set_curriculum_pack_enabled.execute({ pack_id: "PACK_GEOGRAPHY", enabled: false });
  assert.equal(store.snapshot().curriculum.allSkills.length, 84);
  const updated = await tools.update_curriculum_settings.execute({
    student_name: "Ada",
    agent_enabled: false,
    agent_instructions: "Ask questions only; never complete assessed work.",
    progression_mode: "soft",
    contact_email: "teacher@example.com",
  });
  assert.equal("maxAttemptsPerLesson" in updated.settings, false);
  assert.equal(updated.settings.studentName, "Ada");
  assert.equal(updated.settings.contactEmail, "teacher@example.com");
  assert.equal(updated.policy.educator_guidance.trusted, false);
  const app = await tools.get_app_state.execute({});
  assert.equal(app.profile.role, "educator");
  assert.equal(app.active_curriculum_policy.agent_enabled, false);
  assert.equal("educator_guidance" in app.active_curriculum_policy, false, "repeated app-state calls carry only a policy revision summary");
  const guide = await tools.get_agent_guide.execute({ section: "educator" });
  assert.match(guide.active_curriculum_policy.educator_guidance.text, /never complete assessed work/);
  assert.equal(guide.active_curriculum_policy.educator_guidance.trusted, false);
  assert.match(guide.active_curriculum_policy.assessment_notice, /not a substitute for supervised/);
  await assert.rejects(tools.update_curriculum_settings.execute({ max_attempts_per_lesson: 1 }), /Unknown input property/);
  await assert.rejects(tools.get_learning_context.execute({}), /Agent tutoring turned off/);
});

test("educator snapshots and WebMCP isolate curricula by owner", async () => {
  const store = createStore({ profile: false });
  const educatorA = store.createProfile("Educator A", { role: "educator" });
  store.updateCurriculum({ name: "A private curriculum" });
  store.updateCurriculumSettings({ studentName: "A_SECRET_STUDENT", contactEmail: "a-secret@example.com", agentInstructions: "A_SECRET_GUIDANCE" });
  const educatorB = store.createProfile("Educator B", { role: "educator" });
  store.updateCurriculum({ name: "B private curriculum" });
  store.updateCurriculumSettings({ studentName: "B_SECRET_STUDENT", contactEmail: "b-secret@example.com", agentInstructions: "B_SECRET_GUIDANCE" });

  store.selectProfile(educatorA.id);
  const snapshotA = JSON.stringify(store.snapshot());
  assert.match(snapshotA, /A_SECRET_STUDENT/);
  assert.doesNotMatch(snapshotA, /B_SECRET_STUDENT|b-secret@example\.com|B_SECRET_GUIDANCE/);
  const workspaceA = JSON.stringify(await toolsFor(store).get_curriculum_workspace.execute({}));
  assert.match(workspaceA, /A_SECRET_STUDENT/);
  assert.doesNotMatch(workspaceA, /B_SECRET_STUDENT|b-secret@example\.com|B_SECRET_GUIDANCE/);

  store.selectProfile(educatorB.id);
  const snapshotB = JSON.stringify(store.snapshot());
  assert.match(snapshotB, /B_SECRET_STUDENT/);
  assert.doesNotMatch(snapshotB, /A_SECRET_STUDENT|a-secret@example\.com|A_SECRET_GUIDANCE/);
});

test("Agent tutoring off blocks learner tutoring and planning mutations but keeps navigation readable", async () => {
  const educator = createStore({ profile: false });
  educator.createProfile("Policy Educator", { role: "educator" });
  educator.updateCurriculumSettings({ studentName: "Agent Learner", agentEnabled: false });
  const assignment = educator.exportCurriculum(undefined, { kind: "private_assignment" });

  const learner = createStore();
  const imported = learner.importCurriculum(assignment);
  assert.equal(imported.reusedMastery, true);
  const tools = toolsFor(learner);
  await assert.rejects(tools.set_learning_preferences.execute({ progression_mode: "soft" }), /Agent tutoring turned off/i);
  await assert.rejects(tools.set_map_plan_mode.execute({ enabled: true }), /Agent tutoring turned off/i);
  await assert.rejects(tools.arrange_map_plan_nodes.execute({ positions: [{ skill_id: "MATH_ARITH_001", x: 10, y: 20 }] }), /Agent tutoring turned off/i);
  await assert.rejects(tools.set_map_plan_nodes_hidden.execute({ skill_ids: ["MATH_ARITH_001"], hidden: true }), /Agent tutoring turned off/i);
  await assert.rejects(tools.start_skill_test.execute({ skill_id: "MATH_ARITH_001" }), /Agent .* turned off/i);
  const navigated = await tools.navigate_learning_app.execute({ view: "map", skill_id: "MATH_ARITH_001" });
  assert.equal(navigated.visible_view, "map");
  assert.equal((await tools.get_app_state.execute({})).active_curriculum_policy.agent_enabled, false);
});

test("agent lesson authoring guide distinguishes checked steps from reviewed proofs", () => {
  const guide = readFileSync(new URL("./CUSTOM_LESSON_SETS.md", import.meta.url), "utf8");
  assert.match(guide, /Checked maths steps are not formal proofs/);
  assert.match(guide, /two deliberately separate judgments/);
  assert.match(guide, /Pending review initially freezes mastery/);
  assert.match(guide, /satisfied.*flawed.*missing.*not_applicable/);
  assert.match(guide, /Improving a native QuickMaths lesson/);
  assert.match(guide, /same lesson ID/);
  assert.match(guide, /open_lesson_creator/);
  assert.match(guide, /Restore original/);
});

test("schemas reject unknown properties and invalid navigation values", async () => {
  const tools = toolsFor(createStore());
  await assert.rejects(tools.get_learning_context.execute({ unexpected: true }), /Unknown input property/);
  await assert.rejects(tools.navigate_learning_app.execute({ view: "somewhere" }), /view is invalid/);
});

test("app, curriculum, and progress tools expose the full learner state", async () => {
  const tools = toolsFor(createStore());
  const app = await tools.get_app_state.execute({});
  const map = await tools.get_curriculum_map.execute({ include_locked: true });
  const summary = await tools.get_progress_summary.execute({});
  assert.equal(app.has_profile, true);
  assert.equal(app.view, "tutorial");
  assert.equal(app.map_scope, "all");
  assert.deepEqual(app.learning_plan, { plan_mode: false, plan_view: true, show_hidden_nodes: false, selected_skill_ids: [], layouts: {}, paths: [], annotations: [], hidden_skill_ids: [] });
  assert.equal(map.skills.length, 84);
  assert.equal(summary.skills.length, 84);
  assert.equal(summary.suggested_next.skill_id, "MATH_ARITH_001");
});

test("agent navigation updates the same visible route and selected skill", async () => {
  const store = createStore();
  const tools = toolsFor(store);
  const result = await tools.navigate_learning_app.execute({ view: "lesson", skill_id: "MATH_ARITH_001" });
  assert.deepEqual(result, { ok: true, visible_view: "lesson", selected_skill_id: "MATH_ARITH_001" });
  assert.equal(store.snapshot().ui.route, "lesson");
});

test("agent navigation opens Settings and normalizes the former data route", async () => {
  const store = createStore();
  const tools = toolsFor(store);
  const settings = await tools.navigate_learning_app.execute({ view: "settings" });
  assert.equal(settings.visible_view, "settings");
  const legacy = await tools.navigate_learning_app.execute({ view: "data" });
  assert.equal(legacy.visible_view, "settings");
});

test("agent navigation opens the Lesson Depot", async () => {
  const store = createStore();
  const result = await toolsFor(store).navigate_learning_app.execute({ view: "depot" });
  assert.equal(result.visible_view, "depot");
  assert.equal(store.snapshot().ui.route, "depot");
});

test("Depot tools return metadata and stage for human confirmation without installing", async () => {
  const store = createStore();
  const lessonDepot = {
    async search() { return [{ id: "PACK_DEMO", name: "Demo", version: "1.0.0", skill_count: 1 }]; },
    async stagePack(id, version) { return { ok: true, id, version, status: "staged", requires_human_confirmation: true }; },
    async stagePacks(packages) { return { ok: true, status: "staged", staged_count: packages.length, sequential_review: true, requires_human_confirmation: true, review_queue: packages }; },
  };
  const tools = Object.fromEntries(buildToolDefinitions(store, agentManifest, lessonDepot).map((tool) => [tool.name, tool]));
  const found = await tools.search_lesson_depot.execute({ query: "demo" });
  assert.equal(found.packages[0].id, "PACK_DEMO");
  const staged = await tools.stage_depot_lesson.execute({ package_id: "PACK_DEMO", version: "1.0.0" });
  assert.equal(staged.requires_human_confirmation, true);
  const batch = await tools.stage_depot_lessons.execute({ packages: [
    { package_id: "PACK_DEMO", version: "1.0.0" },
    { package_id: "PACK_SECOND", version: "2.0.0" },
  ] });
  assert.equal(batch.staged_count, 2);
  assert.equal(batch.sequential_review, true);
  await assert.rejects(tools.stage_depot_lessons.execute({ packages: [{ package_id: "PACK_DEMO", version: "1.0.0" }] }), /between 2 and 20/);
  assert.equal(store.snapshot().lessonPacks.length, 0);
  assert.equal(tools.install_depot_lesson, undefined);
});

test("Agent activity includes tool actions but excludes learner UI actions", async () => {
  const store = createStore();
  const tools = toolsFor(store);
  assert.deepEqual(store.snapshot().activity, []);

  store.setLearningPreferences({ progressionMode: "soft" });
  assert.deepEqual(store.snapshot().activity, []);

  await tools.set_learning_preferences.execute({ progression_mode: "hard" });
  const activity = store.snapshot().activity;
  assert.equal(activity.length, 1);
  assert.equal(activity[0].actor, "agent");
  assert.equal(activity[0].tool, "set_learning_preferences");
  assert.equal(store.snapshot().activeProfile.agentActivityAt, "2026-09-01T09:42:00.000Z");
});

test("subject tools describe the combined curriculum and open the no-code creator", async () => {
  const store = createStore();
  let tools = toolsFor(store);
  const nativeSubjects = await tools.list_subjects.execute({});
  assert.equal(nativeSubjects.active_subject_id, "SUBJECT_MATH");
  assert.deepEqual(nativeSubjects.subjects.map((subject) => [subject.subject_id, subject.skill_count]), [["SUBJECT_MATH", 84]]);
  store.importLessonPack(geographyLessonSet);
  tools = toolsFor(store);
  const installedSubjects = await tools.list_subjects.execute({});
  assert.deepEqual(installedSubjects.subjects.map((subject) => [subject.subject_id, subject.skill_count]), [
    ["SUBJECT_MATH", 84], ["SUBJECT_GEOGRAPHY", 15],
  ]);
  const changed = await tools.set_learning_preferences.execute({ progression_mode: "soft" });
  assert.equal(changed.progression_mode, "soft");
  const combinedMap = await tools.get_curriculum_map.execute({});
  assert.equal(combinedMap.scope, "all");
  assert.equal(combinedMap.skills.length, 99);
  assert.deepEqual(new Set(combinedMap.skills.map((skill) => skill.subject_id)), new Set(["SUBJECT_MATH", "SUBJECT_GEOGRAPHY"]));
  await assert.rejects(tools.get_curriculum_map.execute({ subject_id: "SUBJECT_MATH" }), /Unknown input property/);
  await assert.rejects(tools.set_learning_preferences.execute({ map_scope: "subject" }), /Unknown input property/);
  const opened = await tools.open_lesson_creator.execute({ subject_id: "SUBJECT_MATH" });
  assert.equal(opened.visible_view, "creator");
  assert.equal(store.snapshot().ui.route, "creator");
});

test("agent planning tools visibly arrange nodes, create paths, and add connected or free comments", async () => {
  const store = createStore();
  const tools = toolsFor(store);
  const opened = await tools.set_map_plan_mode.execute({ enabled: true });
  assert.equal(opened.visible_view, "map");
  assert.equal(opened.plan_mode, true);

  const arranged = await tools.arrange_map_plan_nodes.execute({
    positions: [
      { skill_id: "MATH_ARITH_001", x: -140, y: -180 },
      { skill_id: "MATH_ARITH_002", x: 420, y: 180 },
    ],
  });
  assert.equal(arranged.layout_key, "all-subjects");
  assert.equal(arranged.moved, 2);

  const hidden = await tools.set_map_plan_nodes_hidden.execute({
    skill_ids: ["MATH_ARITH_002"],
    hidden: true,
  });
  assert.deepEqual(hidden.hidden_skill_ids, ["MATH_ARITH_002"]);
  const restored = await tools.set_map_plan_nodes_hidden.execute({
    skill_ids: ["MATH_ARITH_002"],
    hidden: false,
  });
  assert.deepEqual(restored.hidden_skill_ids, []);

  const created = await tools.create_map_plan_path.execute({
    skill_ids: ["MATH_ARITH_001", "MATH_ARITH_002"],
    name: "Arithmetic route",
    color: "#3366aa",
  });
  assert.equal(created.path.name, "Arithmetic route");
  assert.equal(created.path.color, "#3366aa");

  const connected = await tools.add_map_plan_annotation.execute({
    body: "Revisit the sign rules before moving on.",
    skill_ids: created.path.skill_ids,
  });
  assert.deepEqual(connected.annotation.target, { skill_ids: created.path.skill_ids });
  const free = await tools.add_map_plan_annotation.execute({ body: "Exam week starts here." });
  assert.deepEqual(free.annotation.target, { map_comment: true });
  assert.deepEqual(free.annotation.positions["all-subjects"], { x: 320, y: 160 });

  const app = await tools.get_app_state.execute({});
  assert.deepEqual(app.learning_plan.layouts["all-subjects"], {
    MATH_ARITH_001: { x: -140, y: -180 },
    MATH_ARITH_002: { x: 420, y: 180 },
  });
  assert.equal(app.learning_plan.paths.length, 1);
  assert.equal(app.learning_plan.annotations.length, 2);
  assert.ok(store.snapshot().activity.some((item) => item.tool === "arrange_map_plan_nodes"));
  assert.ok(store.snapshot().activity.some((item) => item.tool === "set_map_plan_nodes_hidden"));
  assert.ok(store.snapshot().activity.some((item) => item.tool === "create_map_plan_path"));
  assert.ok(store.snapshot().activity.some((item) => item.tool === "add_map_plan_annotation"));

  const closed = await tools.set_map_plan_mode.execute({ enabled: false });
  assert.equal(closed.plan_mode, false);
  assert.equal(store.snapshot().mapPlan.paths.length, 1);
});

test("agent planning schemas reject unknown nodes, invalid coordinates, and removed path annotation targets", async () => {
  const tools = toolsFor(createStore());
  await assert.rejects(tools.create_map_plan_path.execute({ skill_ids: ["MATH_ARITH_001"] }), /at least 2 skills/);
  await assert.rejects(tools.create_map_plan_path.execute({ skill_ids: ["MATH_ARITH_001", "NOT_A_SKILL"] }), /Unknown skill_id/);
  await assert.rejects(tools.arrange_map_plan_nodes.execute({ positions: [{ skill_id: "MATH_ARITH_001", x: -20001, y: 20 }] }), /-20000 to 20000/);
  const path = await tools.create_map_plan_path.execute({ skill_ids: ["MATH_ARITH_001", "MATH_ARITH_002"] });
  await assert.rejects(tools.add_map_plan_annotation.execute({ body: "Removed target", path_id: path.path.path_id }), /Unknown input property: path_id/);
});

test("cross-subject agent paths automatically use the combined mastery map", async () => {
  const store = createStore();
  store.importLessonPack(geographyLessonSet);
  const created = await toolsFor(store).create_map_plan_path.execute({
    skill_ids: ["MATH_GEOM_003", "GEO_FOUND_001"],
    name: "Coordinates into geography",
  });
  assert.equal(created.map_scope, "all");
  assert.equal(store.snapshot().mapScope, "all");
  assert.deepEqual(created.path.skill_ids, ["MATH_GEOM_003", "GEO_FOUND_001"]);
});

test("agent can visibly prefill a native lesson improvement without installing it", async () => {
  const store = createStore();
  const calls = [];
  const lessonStudio = {
    loadNativeLesson(skillId, options) {
      calls.push({ skillId, options });
      return { ok: true, mode: "override", skillId, completedProgressPreserved: true };
    },
  };
  const tools = Object.fromEntries(buildToolDefinitions(store, agentManifest, null, lessonStudio).map((tool) => [tool.name, tool]));
  const opened = await tools.open_lesson_creator.execute({ skill_id: "MATH_ARITH_001" });
  assert.equal(opened.visible_view, "creator");
  assert.equal(opened.editing_mode, "native_override");
  assert.equal(opened.completed_progress_preserved, true);
  assert.equal(opened.unfinished_tests_restart_on_install, true);
  assert.deepEqual(calls, [{ skillId: "MATH_ARITH_001", options: { announce: false } }]);
  assert.equal(store.snapshot().lessonPacks.length, 0);
  assert.equal(JSON.stringify(opened).includes("expected_answer"), false);
});

test("lesson-set tools validate and stage content but cannot install it", async () => {
  const store = createStore();
  const tools = toolsFor(store);
  const raw = readFileSync(new URL("./lesson-set-example.json", import.meta.url), "utf8");
  const validated = await tools.validate_lesson_set.execute({ lesson_set_json: raw });
  assert.equal(validated.valid, true);
  assert.equal(store.snapshot().lessonPacks.length, 0);
  const staged = await tools.stage_custom_lesson_set.execute({ lesson_set_json: raw });
  assert.equal(staged.requires_human_confirmation, true);
  assert.equal(store.snapshot().ui.route, "settings");
  assert.equal(store.snapshot().stagedLessonPack.id, "PACK_PERSONAL_FINANCE");
  assert.equal(store.snapshot().lessonPacks.length, 0);
  assert.equal(tools.confirm_lesson_set_install, undefined);
  const restored = createStore({ profile: false });
  restored.importSyncState(store.exportSyncState());
  const restoredTools = toolsFor(restored);
  const app = await restoredTools.get_app_state.execute({});
  assert.equal(restored.snapshot().stagedLessonPack.id, "PACK_PERSONAL_FINANCE");
  assert.equal(restored.snapshot().lessonPacks.length, 0);
  assert.equal(restoredTools.confirm_lesson_set_install, undefined);
  assert.doesNotMatch(JSON.stringify(app), /expected_answer|expectedAnswer|solution_steps|solutionSteps/);
});

test("lesson-set tools validate and stage native improvements for human confirmation", async () => {
  const store = createStore();
  const tools = toolsFor(store);
  const raw = JSON.stringify(nativeImprovement(store));
  const validated = await tools.validate_lesson_set.execute({ lesson_set_json: raw });
  assert.equal(validated.preview.mode, "override");
  assert.deepEqual(validated.preview.overridesNativeSkills, ["MATH_ARITH_001"]);
  const staged = await tools.stage_custom_lesson_set.execute({ lesson_set_json: raw });
  assert.equal(staged.requires_human_confirmation, true);
  assert.equal(store.snapshot().stagedLessonPack.mode, "override");
  assert.equal(store.snapshot().lessonPacks.length, 0);
  assert.equal(JSON.stringify({ validated, staged }).includes("expected_answer"), false);
});

test("agent state identifies installed native improvements without exposing their answer keys", async () => {
  const store = createStore();
  store.importLessonPack(nativeImprovement(store));
  const tools = toolsFor(store);
  const app = await tools.get_app_state.execute({});
  const map = await tools.get_curriculum_map.execute({});
  const improved = map.skills.find((skill) => skill.skill_id === "MATH_ARITH_001");
  assert.equal(app.custom_lesson_sets.length, 0);
  assert.equal(app.lesson_changes[0].mode, "override");
  assert.deepEqual(app.lesson_changes[0].overrides_native_skills, ["MATH_ARITH_001"]);
  assert.equal(improved.native, true);
  assert.equal(improved.overridden, true);
  assert.equal(improved.pack_id, "PACK_IMPROVE_MATH_ARITH_001");
  assert.equal(JSON.stringify({ app, map }).includes("expected_answer"), false);
});

test("starting a test exposes prompts but not expected answers", async () => {
  const store = createStore();
  const tools = toolsFor(store);
  const started = await tools.start_skill_test.execute({ skill_id: "MATH_ARITH_001" });
  const context = await tools.get_learning_context.execute({ include_history: true });
  const serialized = JSON.stringify({ started, context });
  assert.equal(started.question_count, 10);
  assert.equal(store.snapshot().ui.route, "test");
  assert.equal(serialized.includes("expected_answer"), false);
  assert.equal(serialized.includes("solution_steps"), false);
});

test("locked test starts are rejected through the agent surface", async () => {
  const tools = toolsFor(createStore());
  await assert.rejects(tools.start_skill_test.execute({ skill_id: "MATH_SYS_001" }), /locked/i);
});

test("agent workflow inspects work, saves feedback, and opens a follow-up", async () => {
  const store = createStore();
  const tools = toolsFor(store);
  await tools.start_skill_test.execute({ skill_id: "MATH_ARITH_001" });
  const draft = store.snapshot().activeTest;
  const first = draft.problems[0];
  store.updateResponse(first.template_id, { finalAnswer: "definitely wrong", work: "I changed the sign." });

  const inspection = await tools.inspect_student_work.execute({ question_id: first.template_id });
  assert.equal(inspection.final_answer_status, "incorrect");
  assert.ok(inspection.mistake_tag);

  const feedback = await tools.record_tutor_feedback.execute({
    question_id: first.template_id,
    feedback: "Check what operation the two signs are asking you to perform.",
    mistake_tag: inspection.mistake_tag,
    next_step: "Rewrite the expression with one sign rule at a time.",
    confidence: "high",
    verdict: "needs_revision",
  });
  assert.equal(feedback.saved, true);
  assert.equal(store.snapshot().reviews.length, 1);
  assert.equal(store.snapshot().backupStatus.recommended, true);

  const followup = await tools.create_followup_problem.execute({
    skill_id: "MATH_ARITH_001",
    focus: inspection.mistake_tag,
  });
  assert.equal(followup.saved, true);
  assert.equal(followup.problem.skill_id, "MATH_ARITH_001");
  assert.ok(draft.problems.some((problem) => problem.template_id === followup.problem.question_id));
  assert.equal(store.snapshot().activeTest.problems[0].template_id, followup.problem.question_id);
});

test("draft-time agent feedback follows the saved attempt", async () => {
  const store = createStore();
  const tools = toolsFor(store);
  await tools.start_skill_test.execute({ skill_id: "MATH_ARITH_001" });
  const draft = store.snapshot().activeTest;
  const first = draft.problems[0];
  store.updateResponse(first.template_id, { finalAnswer: String(first.expected_answer), work: "" });
  await tools.record_tutor_feedback.execute({
    question_id: first.template_id,
    feedback: "Your sign reasoning is clear.",
    next_step: "Finish the remaining questions with the same sign check.",
    confidence: "high",
    verdict: "pass",
  });
  for (const problem of draft.problems) {
    store.updateResponse(problem.template_id, { finalAnswer: String(problem.expected_answer), work: "" });
  }
  assert.equal(store.submitTest().ok, true);
  const attempt = store.saveReflection({
    confidenceRating: 4,
    difficultyFelt: "medium",
    hintsUsed: "none",
    guessed: "no",
    wantsMorePractice: "yes",
  });
  assert.equal(store.snapshot().reviews[0].attemptId, attempt.attemptId);
  const savedInspection = await tools.inspect_student_work.execute({ question_id: first.template_id });
  assert.equal(savedInspection.source, "saved_attempt");
  assert.equal(savedInspection.attempt_id, attempt.attemptId);
  assert.equal(savedInspection.latest_review.reviewId, store.snapshot().reviews[0].reviewId);
  assert.equal(JSON.stringify(savedInspection).includes("expectedAnswer"), false);
});

test("registration reports partial failure without duplicating names", async () => {
  const registered = [];
  const result = await registerWebMcpTools(createStore(), {
    async registerTool(definition) {
      if (definition.name === TOOL_NAMES[3]) throw new Error("unsupported schema keyword");
      registered.push(definition.name);
    },
  }, agentManifest);
  assert.equal(result.available, true);
  assert.deepEqual(result.registered, TOOL_NAMES.filter((name) => name !== TOOL_NAMES[3]));
  assert.deepEqual(result.failures, [{ name: TOOL_NAMES[3], error: "unsupported schema keyword" }]);
  assert.match(result.error, new RegExp(TOOL_NAMES[3]));
});


test("field and branch tools expose scoped lesson membership and reject unknown fields", async () => {
  const store = createStore(); const tools = toolsFor(store);
  const fields = await tools.list_fields.execute({});
  assert.equal(fields.fields[0].id, "SUBJECT_MATH");
  const branches = await tools.list_branches.execute({ field_id: "SUBJECT_MATH" });
  assert.ok(branches.branches.length > 1);
  assert.ok(branches.branches.every((branch) => branch.fieldId === "SUBJECT_MATH" && branch.skillIds.length));
  await assert.rejects(tools.list_branches.execute({ field_id: "missing" }), /Unknown field_id/);
  assert.deepEqual((await tools.list_subjects.execute({})).subjects.map((subject) => subject.subject_id), fields.fields.map((field) => field.id));
  const guide = await tools.get_lesson_authoring_guide.execute({ section: "envelope" });
  assert.match(JSON.stringify(guide), /Envelope and field/);
});
