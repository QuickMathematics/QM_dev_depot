import test from "node:test";
import assert from "node:assert/strict";

import { createLessonStudio } from "./lesson-creator.js";
import { gradeProblem, normalizeLessonPack } from "./challenge-core.js";

function snapshot() {
  const activeSubject = {
    id: "SUBJECT_MATH", name: "Mathematics", shortName: "Maths", icon: "∑",
    description: "Mathematics curriculum.", skillIds: [],
    theme: {
      paper: "#eef6f1", paperDeep: "#dcebe2", paperLight: "#ffffff", ink: "#18231d",
      muted: "#607067", line: "#c7d8ce", primary: "#225c48", primaryAlt: "#33765e",
      tint: "#bfe2ce", highlight: "#e4ef9b", accent: "#e06b54",
    },
  };
  const nativeSkill = {
    id: "MATH_ARITH_001", name: "Integer operations", domain: "Math", subdomain: "Arithmetic",
    description: "Operate with signed integers.", subjectId: activeSubject.id, native: true, custom: false, overridden: false,
    prerequisites: [], unlocks: [], tags: ["integers"],
    mastery: { passing_score: .8, minimum_confidence: 3, max_guessing_allowed: "maybe", review_after_days_if_mastered: 7, review_after_days_if_learning: 2 },
    theory: "Integers include positive numbers, negative numbers, and zero.", examples: [], applications: [],
    problems: [{
      template_id: "INTEGER_NATIVE_Q01", source_template_id: "INTEGER_NATIVE_SCENARIO", skill_id: "MATH_ARITH_001", difficulty: "easy", prompt: "Compute -2 + 5.",
      expected_answer: "3", answer_type: "integer", grading_method: "exact_numeric", solution_steps: ["Add five to negative two."],
      mistake_tags: ["signs"], answer_mode: "final_only", work: { mode: "none" },
      review_policy: { work_review: "none", mastery_requires_review_pass: false, allow_self_review: true },
    }],
  };
  return { activeSubject, subjects: [activeSubject], selectedSkill: nativeSkill, curriculum: { allSkills: [nativeSkill] } };
}

function studioHarness({ questionCount = 1 } = {}) {
  const state = snapshot();
  const source = state.curriculum.allSkills[0];
  while (source.problems.length < questionCount) {
    const index = source.problems.length;
    source.problems.push({ ...structuredClone(source.problems[0]), template_id: `INTEGER_NATIVE_Q${String(index + 1).padStart(2, "0")}`, prompt: `Native question ${index + 1}` });
  }
  const studio = createLessonStudio({
    store: {
      skillsById: Object.fromEntries(state.curriculum.allSkills.map((skill) => [skill.id, skill])),
      previewLessonPack() { return { name: "Pack", mode: "add", skillCount: 1, problemCount: 1, subjectName: "Mathematics" }; },
      previewNativeAssessment(skillId, variation) {
        return { ok: true, skillId, skillName: source.name, variation, templateCount: 1, problems: [{ ...structuredClone(source.problems[0]), template_id: `INTEGER_NATIVE_SCENARIO__RUNTIME_${variation + 1}`, values: { a: String(variation + 2), b: "5" } }] };
      },
    },
    download() {}, showToast() {}, getSnapshot: () => state, openFilePicker() {},
  });
  return { studio, state };
}

function changeWorkMode(studio, value) {
  return studio.handleInput({
    value, type: "select", checked: false,
    dataset: { creatorField: "problem.workMode", index: "0" },
    matches() { return false; },
  });
}

function changeProblemField(studio, field, value, { type = "text", checked = false } = {}) {
  return studio.handleInput({ value, type, checked, dataset: { creatorField: `problem.${field}`, index: "0" }, matches() { return false; } });
}

test("Lesson Studio explains proof syntax and builds a required reviewed proof", () => {
  const { studio, state } = studioHarness();
  assert.equal(changeWorkMode(studio, "proof_obligations"), true);
  const html = studio.render(state);
  const problem = studio.buildPack().skills[0].problems[0];

  assert.match(html, /Author a proof skeleton, not a secret answer/);
  assert.match(html, /Formal proof required — reviewed before mastery/);
  assert.match(html, /Question response type/);
  assert.match(html, /Advanced Algebra/);
  assert.match(html, /One question, two judgments, four stages/);
  assert.match(html, /WebMCP tutor judges validity/);
  assert.match(html, /Learner view preview/);
  assert.match(html, /ordinary text/);
  assert.match(html, /Mastery waits for a passed review/);
  assert.equal(problem.answer_mode, "final_plus_required_work");
  assert.equal(problem.work.mode, "proof_obligations");
  assert.equal(problem.review_policy.work_review, "tutor_required");
  assert.equal(problem.review_policy.mastery_requires_review_pass, true);
  assert.equal(problem.review_policy.allow_self_review, false);
  assert.ok(problem.work.proof_policy.obligations.length >= 3);
});

test("Lesson Studio help controls expose tappable tooltip content", () => {
  const { studio, state } = studioHarness();
  const html = studio.render(state);
  assert.match(html, /data-studio-help/);
  assert.match(html, /data-tooltip="Advanced Algebra-style steps are checked automatically/);
  assert.match(html, /aria-expanded="false"/);
  assert.match(html, /Tap or hover any/);
});

test("advanced authoring examples populate readable proof and rubric guidance", () => {
  const { studio, state } = studioHarness();
  changeWorkMode(studio, "proof_obligations");
  studio.handleAction({ dataset: { creatorAction: "apply-proof-example", index: "0" } });
  let problem = studio.buildPack().skills[0].problems[0];
  assert.match(problem.work.prompt, /plain language/i);
  assert.equal(problem.grading_method, "theorem_conclusion");
  assert.equal(problem.expected_answer, "sqrt(2) is irrational");
  assert.equal(problem.work.proof_policy.obligations.length, 6);
  assert.deepEqual(problem.work.proof_policy.accepted_strategies, ["Contradiction using parity"]);
  assert.equal(problem.review_policy.mastery_requires_review_pass, true);

  changeWorkMode(studio, "rubric_check");
  studio.handleAction({ dataset: { creatorAction: "apply-rubric-example", index: "0" } });
  const html = studio.render(state);
  problem = studio.buildPack().skills[0].problems[0];
  assert.match(html, /Describe observable qualities/);
  assert.match(html, /response will be reviewed for/i);
  assert.equal(problem.work.rubric.criteria.length, 5);
  assert.equal(problem.review_policy.mastery_requires_review_pass, true);
});

test("Lesson Studio authors rational-equation and sign-chart contracts without raw JSON", () => {
  const { studio, state } = studioHarness();
  changeProblemField(studio, "gradingMethod", "finite_set");
  changeProblemField(studio, "answerValues", "-2\n5");
  changeWorkMode(studio, "rational_equation_steps");
  changeProblemField(studio, "originalEquation", "(x - 5)/(x + 2) = 0");
  changeProblemField(studio, "expectedRestrictions", "-2");
  let problem = studio.buildPack().skills[0].problems[0];
  assert.equal(problem.grading_method, "finite_set");
  assert.deepEqual(problem.answer_metadata.values, ["-2", "5"]);
  assert.equal(problem.work.mode, "rational_equation_steps");
  assert.equal(problem.work.require_restrictions, true);
  assert.equal(problem.work.require_original_equation_check, true);
  assert.equal(problem.work.original_equation, "(x - 5)/(x + 2) = 0");
  assert.deepEqual(problem.work.expected_restrictions, ["-2"]);
  assert.equal(problem.review_policy.work_review, "auto");
  assert.match(studio.render(state), /learner sees a form, not JSON/i);

  changeProblemField(studio, "gradingMethod", "interval_set");
  changeProblemField(studio, "expectedAnswer", "(-inf, 2] U (5, inf)");
  changeWorkMode(studio, "sign_chart_steps");
  changeProblemField(studio, "signExpressionKind", "rational");
  changeProblemField(studio, "signExpression", "(x - 2)\/(x - 5)");
  changeProblemField(studio, "signRelation", ">=");
  changeProblemField(studio, "criticalPoints", "2 | zero | 1 | x - 2\n5 | undefined | 1 | x - 5");
  problem = studio.buildPack().skills[0].problems[0];
  assert.equal(problem.grading_method, "interval_set");
  assert.equal(problem.work.mode, "sign_chart_steps");
  assert.equal(problem.work.sign_chart.expression_kind, "rational");
  assert.deepEqual(problem.work.sign_chart.critical_points.map(({ value, kind }) => ({ value, kind })), [{ value: "2", kind: "zero" }, { value: "5", kind: "undefined" }]);
  assert.match(studio.render(state), /value \| kind \| multiplicity \| factor/);
});

test("Lesson Studio authors formatted code and structured trace tables without response JSON", () => {
  const { studio, state } = studioHarness();
  changeProblemField(studio, "promptCode", "x = 2\nx += 3\nprint(x)");
  changeWorkMode(studio, "code_trace_steps");
  changeProblemField(studio, "traceDisplayCode", "x = 2\nx += 3\nprint(x)");
  changeProblemField(studio, "traceColumns", "step\nx\noutput");
  changeProblemField(studio, "traceRows", "1 | 2 |\n2 | 5 |\n3 | 5 | 5");
  const problem = studio.buildPack().skills[0].problems[0];
  const html = studio.render(state);
  assert.equal(problem.prompt_blocks[1].type, "code");
  assert.equal(problem.prompt_blocks[1].text, "x = 2\nx += 3\nprint(x)");
  assert.equal(problem.work.mode, "code_trace_steps");
  assert.deepEqual(problem.work.trace_spec.columns, ["step", "x", "output"]);
  assert.deepEqual(problem.work.trace_spec.expected_rows.at(-1), { step: 3, x: 5, output: 5 });
  assert.equal(problem.review_policy.work_review, "auto");
  assert.match(html, /table is authored; lesson code is never executed/i);
  assert.match(html, /Expected rows — pipe-separated cells/);
});

test("Lesson Studio builds a declarative sandboxed Python function contract", () => {
  const { studio, state } = studioHarness();
  studio.handleAction({ dataset: { creatorAction: "apply-python-example", index: "0" } });
  const problem = studio.buildPack().skills[0].problems[0];
  const html = studio.render(state);
  assert.equal(problem.grading_method, "python_program");
  assert.equal(problem.answer_type, "code");
  assert.equal(problem.program_spec.runtime, "python_subset_v1");
  assert.equal(problem.program_spec.entrypoint.name, "is_even");
  assert.deepEqual(problem.program_spec.entrypoint.parameters, [{ name: "number", type: "int" }]);
  assert.equal(problem.program_spec.tests.length, 4);
  assert.equal(problem.program_spec.tests.filter((item) => item.visibility === "hidden").length, 2);
  assert.deepEqual(problem.program_spec.policy.imports, []);
  assert.equal(problem.program_spec.policy.network, false);
  assert.match(html, /Declarative tests, isolated learner code/);
  assert.match(html, /visibility \| id \| arguments JSON \| expected JSON/);
});

test("Lesson Studio opens native lessons as reversible overrides without changing identity", () => {
  const { studio, state } = studioHarness();
  const opened = studio.loadNativeLesson("MATH_ARITH_001", { announce: false });
  const pack = studio.buildPack();
  const html = studio.render(state);

  assert.equal(opened.mode, "override");
  assert.equal(opened.completedProgressPreserved, true);
  assert.equal(pack.mode, "override");
  assert.deepEqual(pack.track.skills, ["MATH_ARITH_001"]);
  assert.equal(pack.skills[0].id, "MATH_ARITH_001");
  assert.equal(pack.skills[0].problems[0].template_id, "INTEGER_NATIVE_Q01");
  assert.equal(pack.skills[0].problems[0].source_template_id, "INTEGER_NATIVE_SCENARIO");
  assert.match(html, /Edit a native lesson/);
  assert.match(html, /Native improvement/);
  assert.match(html, /completed progress remain preserved/);
  assert.match(html, /Original native runtime generator/);
  assert.match(html, /Variation 1/);
  assert.match(html, /Install improvement/);
  assert.match(html, /readonly/);
  studio.handleAction({ dataset: { creatorAction: "reroll-native-preview" } });
  assert.match(studio.render(state), /Variation 2/);
});

test("large native question banks render one editable question at a time", () => {
  const { studio, state } = studioHarness({ questionCount: 30 });
  studio.loadNativeLesson("MATH_ARITH_001", { announce: false });
  const html = studio.render(state);
  assert.equal((html.match(/data-creator-action="select-problem"/g) ?? []).length, 30);
  assert.equal((html.match(/class="studio-problem-body"/g) ?? []).length, 1);
  assert.match(html, /Editing question 1 of 30/);
  assert.equal(studio.buildPack().skills[0].problems.length, 30);
  studio.handleAction({ dataset: { creatorAction: "select-problem", index: "12" } });
  const selectedHtml = studio.render(state);
  assert.match(selectedHtml, /Editing question 13 of 30/);
  assert.match(selectedHtml, /Native question 13/);
});

test("an untouched Studio draft follows the active subject instead of defaulting to Mathematics", () => {
  const state = snapshot();
  const programming = {
    ...structuredClone(state.activeSubject), id: "SUBJECT_PROGRAMMING", name: "Programming", shortName: "Python", icon: "λ",
  };
  state.activeSubject = programming;
  state.subjects.push(programming);
  const studio = createLessonStudio({
    store: { skillsById: {}, previewLessonPack() { return {}; } },
    download() {}, showToast() {}, getSnapshot: () => state, openFilePicker() {},
  });
  studio.render(state);
  assert.equal(studio.buildPack().subject.id, "SUBJECT_PROGRAMMING");
  assert.equal(studio.buildPack().subject.name, "Programming");
});


test("Studio lists field-scoped branches and exports compatible lesson file keys", () => {
  const { studio, state } = studioHarness();
  state.curriculum.allSkills.push({ id: "OTHER", name: "Other lesson", subjectId: "SUBJECT_OTHER", subdomain: "Other branch", custom: true });
  const html = studio.render(state);
  assert.doesNotMatch(html, /Word for lesson files/);
  assert.match(html, /Existing field/);
  assert.match(html, /datalist id="studio-branches"/);
  const branches = html.match(/<datalist id="studio-branches">(.*?)<\/datalist>/)[1];
  assert.match(branches, /Arithmetic/);
  assert.doesNotMatch(branches, /Other branch/);
  studio.handleInput({ value: "Geometry", type: "text", matches: () => false, dataset: { creatorField: "skill.subdomain" } });
  const pack = studio.buildPack();
  assert.equal(pack.subject.id, "SUBJECT_MATH");
  assert.equal(pack.skills[0].subdomain, "Geometry");
});


test("Studio opens old lesson categories as branch and topic and round-trips both", () => {
  const { studio, state } = studioHarness();
  studio.loadNativeLesson(state.selectedSkill.id);
  const pack = studio.buildPack();
  pack.skills[0].subdomain = "Quadratic Equations"; delete pack.skills[0].topic;
  assert.equal(studio.loadRaw(JSON.stringify(pack)), true);
  const migrated = studio.buildPack();
  assert.equal(migrated.skills[0].subdomain, "Algebra");
  assert.equal(migrated.skills[0].topic, "Quadratic Equations");
  assert.deepEqual(migrated.skills[0].problems, pack.skills[0].problems);
  assert.match(studio.render(state), /Topic \(optional\)/);
});


test("Studio field choices persist across renders and update only the untouched default branch", () => {
  const { studio, state } = studioHarness();
  state.subjects.push({ ...state.activeSubject, id: "SUBJECT_PROGRAMMING", name: "Programming" });
  const change = (path, value) => studio.handleInput({ value, type: "text", matches: () => false, dataset: { creatorField: path } });
  change("draft.subjectId", "SUBJECT_PROGRAMMING");
  studio.render(state);
  assert.equal(studio.buildPack().subject.id, "SUBJECT_PROGRAMMING");
  assert.equal(studio.buildPack().skills[0].subdomain, "Programming Fundamentals");
  change("skill.subdomain", "My custom branch");
  change("skill.topic", "My topic");
  change("draft.subjectId", "SUBJECT_MATH");
  studio.render(state);
  assert.equal(studio.buildPack().subject.id, "SUBJECT_MATH");
  assert.equal(studio.buildPack().skills[0].subdomain, "My custom branch");
  assert.equal(studio.buildPack().skills[0].topic, "My topic");
});


test("deleting then adding lessons and questions keeps IDs unique and removes deleted prerequisites", (t) => {
  const previousConfirm = globalThis.confirm;
  globalThis.confirm = () => true;
  t.after(() => { if (previousConfirm) globalThis.confirm = previousConfirm; else delete globalThis.confirm; });
  const { studio } = studioHarness();
  const act = (creatorAction, index = 0) => studio.handleAction({ dataset: { creatorAction, index: String(index) } });
  act("add-skill"); act("add-skill");
  studio.handleInput({ matches: () => true, selectedOptions: [{ value: "CUSTOM_NEW_LESSON_002" }] });
  act("select-skill", 1); act("remove-skill"); act("add-skill");
  const pack = studio.buildPack();
  assert.equal(new Set(pack.skills.map(skill => skill.id)).size, 3);
  assert.deepEqual(pack.skills[1].prerequisites, []);
  act("add-problem"); act("add-problem"); act("remove-problem", 1); act("add-problem");
  const problems = studio.buildPack().skills.flatMap(skill => skill.problems);
  assert.equal(new Set(problems.map(problem => problem.template_id)).size, problems.length);
});

test("opening an existing add-on preserves long IDs and prerequisite references", () => {
  const { studio } = studioHarness();
  const pack = studio.buildPack();
  pack.id = "PACK_" + "A".repeat(50);
  pack.subject.id = "SUBJECT_" + "B".repeat(46);
  pack.skills[0].id = "CUSTOM_" + "C".repeat(48);
  pack.skills[0].problems[0].template_id = "QUESTION_" + "D".repeat(95);
  pack.skills[0].problems[0].source_template_id = pack.skills[0].problems[0].template_id;
  const second = structuredClone(pack.skills[0]);
  second.id = "CUSTOM_OTHER_LESSON";
  second.problems[0].template_id = "ORIGINAL_QUESTION_ID";
  second.prerequisites = [pack.skills[0].id];
  pack.skills.push(second);
  assert.equal(studio.loadRaw(JSON.stringify(pack)), true);
  const saved = studio.buildPack();
  assert.equal(saved.id, pack.id);
  assert.equal(saved.subject.id, pack.subject.id);
  assert.deepEqual(saved.skills.map(skill => skill.id), pack.skills.map(skill => skill.id));
  assert.deepEqual(saved.skills.map(skill => skill.problems[0].template_id), pack.skills.map(skill => skill.problems[0].template_id));
  assert.deepEqual(saved.skills[1].prerequisites, [saved.skills[0].id]);
});

test("a lesson imported without questions receives an editable starter question", () => {
  const { studio, state } = studioHarness();
  const pack = studio.buildPack(); pack.skills[0].problems = [];
  assert.equal(studio.loadRaw(JSON.stringify(pack)), true);
  assert.doesNotThrow(() => studio.render(state));
  changeProblemField(studio, "prompt", "New prompt");
  assert.equal(studio.buildPack().skills[0].problems[0].prompt, "New prompt");
});


test("editing a native equation lesson preserves a target variable other than x", () => {
  const { studio, state } = studioHarness();
  const source = state.curriculum.allSkills[0].problems[0];
  source.variable = "n"; source.grading_method = "equation_solution"; source.expected_answer = "11";
  studio.loadNativeLesson(state.selectedSkill.id);
  const question = studio.buildPack().skills[0].problems[0];
  assert.equal(question.variable, "n");
  assert.equal(gradeProblem(question, "n=11").correct, true);
  assert.equal(gradeProblem(question, "x=11").correct, false);
});

test("renaming draft lessons keeps prerequisites attached through temporary ID collisions and reload", (t) => {
  const values = new Map();
  const previousStorage = globalThis.localStorage;
  const previousConfirm = globalThis.confirm;
  globalThis.localStorage = { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, value) };
  globalThis.confirm = () => true;
  t.after(() => { globalThis.localStorage = previousStorage; globalThis.confirm = previousConfirm; });
  let { studio } = studioHarness();
  const act = (action, index = 0) => studio.handleAction({ dataset: { creatorAction: action, index: String(index) } });
  const rename = value => studio.handleInput({ value, dataset: { creatorField: "skill.id" }, matches: () => false });
  act("add-skill");
  studio.handleInput({ matches: () => true, selectedOptions: [{ value: "CUSTOM_NEW_LESSON_001" }] });
  act("select-skill", 0);
  rename("CUSTOM_NEW_LESSON_002"); // A temporary duplicate while typing must not move the second lesson's links.
  rename("renamed lesson");
  ({ studio } = studioHarness());
  assert.deepEqual(studio.buildPack().skills[1].prerequisites, ["CUSTOM_RENAMED_LESSON"]);
  act("add-skill");
  assert.equal(new Set(studio.buildPack().skills.map(skill => skill.id)).size, 3);
  act("select-skill", 0); act("remove-skill");
  assert.deepEqual(studio.buildPack().skills[0].prerequisites, []);
});

test("opening a lesson preserves structured prerequisites and mastery rules", () => {
  const { studio } = studioHarness();
  const source = studio.buildPack();
  source.skills[0].prerequisites = [{ skill_id: "CUSTOM_EXTERNAL", subject_id: "SUBJECT_EXTERNAL" }];
  source.skills[0].mastery.max_guessing_allowed = "no";
  studio.loadRaw(JSON.stringify(source));
  assert.deepEqual(studio.buildPack().skills[0].prerequisites, source.skills[0].prerequisites);
  assert.deepEqual(studio.buildPack().skills[0].mastery, source.skills[0].mastery);
  source.skills[0].prerequisites = ["CUSTOM_EXTERNAL"];
  source.skills[0].prerequisiteRefs = [{ skillId: "CUSTOM_EXTERNAL", subjectId: "SUBJECT_EXTERNAL" }];
  studio.loadRaw(JSON.stringify(source));
  assert.deepEqual(studio.buildPack().skills[0].prerequisites, [{ skill_id: "CUSTOM_EXTERNAL", subject_id: "SUBJECT_EXTERNAL" }]);
});

test("trace authoring round trips strings, separators, and strict comparison rules", () => {
  const { studio } = studioHarness();
  changeWorkMode(studio, "code_trace_steps");
  const source = studio.buildPack();
  const trace = source.skills[0].problems[0].work.trace_spec;
  trace.columns = ["step", "output"];
  trace.expected_rows = [
    { step: 1, output: "001" }, { step: 2, output: "false" }, { step: 3, output: ' left | "right"\nnext ' },
    { step: 4, output: false }, { step: 5, output: null },
  ];
  trace.comparison = { trim_strings: false, numeric_equivalence: false, blank_equals_null: false };
  studio.loadRaw(JSON.stringify(source));
  assert.deepEqual(studio.buildPack().skills[0].problems[0].work.trace_spec, trace);
  changeProblemField(studio, "traceRows", '1 | "a|b"\n2 | " padded "');
  assert.deepEqual(studio.buildPack().skills[0].problems[0].work.trace_spec.expected_rows, [{ step: 1, output: "a|b" }, { step: 2, output: " padded " }]);
  changeProblemField(studio, "traceRows", "1 | extra | discarded");
  assert.throws(() => studio.buildPack(), /cells|columns/i);
});

test("Python test authoring preserves pipes and escaped quotes inside JSON strings", () => {
  const { studio } = studioHarness();
  studio.handleAction({ dataset: { creatorAction: "apply-python-example", index: "0" } });
  const source = studio.buildPack();
  const program = source.skills[0].problems[0].program_spec;
  program.tests = [{ visibility: "example", id: "pipes", args: ['a|b', { text: 'a\\"|b' }], expected_return: " left | right " }];
  program.limits.memory_mb = 64;
  studio.loadRaw(JSON.stringify(source));
  assert.deepEqual(studio.buildPack().skills[0].problems[0].program_spec, program);
});

test("editing lesson text preserves prompt blocks, proof obligations and weighted rubric identities", () => {
  const { studio } = studioHarness();
  changeWorkMode(studio, "proof_obligations");
  const source = studio.buildPack();
  const problem = source.skills[0].problems[0];
  problem.prompt_blocks = [{ type: "text", text: problem.prompt }, { type: "code", language: "python", text: "x = 1" }, { type: "text", text: "Then consider this variation." }, { type: "code", language: "python", text: "x = 2" }];
  problem.work.proof_policy.obligations = [{ id: "main_claim", description: "State the claim", required: true }, { id: "extension", description: "Discuss an extension", required: false }];
  problem.work.require_final_answer_match = false;
  problem.work.target_variable = "n";
  studio.loadRaw(JSON.stringify(source));
  changeProblemField(studio, "prompt", "Updated question");
  changeProblemField(studio, "promptCode", "x = 3");
  const saved = studio.buildPack().skills[0].problems[0];
  assert.deepEqual(saved.work.proof_policy, problem.work.proof_policy);
  assert.equal(saved.work.require_final_answer_match, false);
  assert.equal(saved.work.target_variable, "n");
  assert.deepEqual(saved.prompt_blocks, [{ type: "text", text: "Updated question" }, { type: "code", language: "python", text: "x = 3" }, ...problem.prompt_blocks.slice(2)]);
  changeWorkMode(studio, "rubric_check");
  const rubricPack = studio.buildPack();
  const criteria = [{ id: "reason", description: "Explains the reason", weight: 4 }, { id: "detail", description: "Includes detail", weight: 1 }];
  rubricPack.skills[0].problems[0].work.rubric.criteria = criteria;
  studio.loadRaw(JSON.stringify(rubricPack));
  assert.deepEqual(studio.buildPack().skills[0].problems[0].work.rubric.criteria, criteria);
  changeProblemField(studio, "rubricCriteria", "Includes detail\nExplains the reason\nAdds an example");
  const editedCriteria = studio.buildPack().skills[0].problems[0].work.rubric.criteria;
  assert.deepEqual(editedCriteria.slice(0, 2), [criteria[1], criteria[0]]);
  assert.equal(new Set(editedCriteria.map(item => item.id)).size, 3);
});

test("Lesson Studio authors a pinned declarative formal proof spec and round-trips its reference proof", () => {
  const { studio, state } = studioHarness();
  studio.handleAction({ dataset: { creatorAction: "apply-formal-example", index: "0" } });
  const html = studio.render(state);
  let problem = studio.buildPack().skills[0].problems[0];
  assert.match(html, /QuickMaths owns the meaning; Lean checks the proof/);
  assert.match(html, /Prove the exercise before publishing it/);
  assert.equal(problem.proof_spec.version, "0.1");
  assert.deepEqual(problem.proof_spec.statement.declarations, ["x:real"]);
  assert.equal(problem.proof_spec.statement.goal, "x^2 - 9 = (x - 3) * (x + 3)");
  assert.deepEqual(problem.proof_spec.allowed_rules, ["ring_identity"]);
  assert.equal(problem.proof_spec.reference_proof.mode, "steps");
  assert.equal(problem.proof_spec.reference_proof.steps[0].rule, "ring_identity");
  assert.equal(problem.proof_spec.environment.backend, "lean4");
  assert.match(problem.proof_spec.environment.toolchain, /lean4:v4\.34\.0-rc2/);
  assert.match(problem.proof_spec.environment.library_revision, /^[a-f0-9]{40}$/);

  problem.proof_spec.assessment_policy = { required_method: "direct", allow_routine_gaps: false };
  problem.proof_spec.parameter_contract = { required_public: ["a"] };
  assert.equal(studio.loadRaw(JSON.stringify(studio.buildPack())), true);
  // Reload the modified object explicitly so the round-trip covers non-UI policy fields too.
  const source = studio.buildPack();
  source.skills[0].problems[0].proof_spec = problem.proof_spec;
  assert.equal(studio.loadRaw(JSON.stringify(source)), true);
  problem = studio.buildPack().skills[0].problems[0];
  assert.deepEqual(problem.proof_spec.assessment_policy, { required_method: "direct", allow_routine_gaps: false });
  assert.deepEqual(problem.proof_spec.parameter_contract.required_public, ["a"]);
});

test("browser ingestion binds a Studio formal question even when the author file has no precomputed job", () => {
  const { studio } = studioHarness();
  studio.handleAction({ dataset: { creatorAction: "apply-formal-example", index: "0" } });
  changeProblemField(studio, "expectedAnswer", "x^2 - 9 = (x - 3) * (x + 3)");
  const authorPack = studio.buildPack();
  assert.equal(authorPack.skills[0].problems[0].formal_job, undefined);
  const normalized = normalizeLessonPack(authorPack, { knownSkillIds: ["MATH_ARITH_001"] });
  const problem = normalized.skills[0].problems[0];
  assert.match(problem.formal_job.problem_binding_sha256, /^[a-f0-9]{64}$/);
  assert.equal(problem.formal_job.rpc.request_id, `quickmaths:${problem.formal_job.problem_binding_sha256}`);
  assert.equal(problem.formal_job.rpc.goal, problem.proof_spec.statement.goal);
  assert.deepEqual(problem.formal_job.environment_requirements, problem.proof_spec.environment);

  const forged = structuredClone(authorPack);
  forged.skills[0].problems[0].formal_job = structuredClone(problem.formal_job);
  forged.skills[0].problems[0].formal_job.problem_binding_sha256 = "0".repeat(64);
  forged.skills[0].problems[0].formal_job.rpc.request_id = `quickmaths:${"0".repeat(64)}`;
  assert.throws(() => normalizeLessonPack(forged, { knownSkillIds: ["MATH_ARITH_001"] }), /binding does not match the displayed problem/);
});

test("Studio reference proof check reports kernel unavailability without claiming certification", async (t) => {
  const previousFetch = globalThis.fetch;
  globalThis.fetch = async (url, options = {}) => {
    const path = new URL(url).pathname;
    if (path === "/health") return { ok: true, status: 200, json: async () => ({
      service: "quickmaths-formal", protocol_version: "0.1", lean_available: false,
      environment: { backend: "lean4", library: "mathlib", lean_toolchain: "leanprover/lean4:v4.34.0-rc2", mathlib_revision: "42a3845c6d7ec6866eefa4cc327a306a0c4a7d3c" },
    }) };
    if (path === "/v1/rpc") {
      const rpc = JSON.parse(options.body);
      assert.equal(rpc.op, "check_reference_text");
      assert.equal(rpc.reference_steps[0].rule, "ring_identity");
      return { ok: true, status: 200, json: async () => ({ protocol_version: "0.1", ok: true, result: {
        request: { request_id: rpc.request_id }, proof_state: { status: "ready_for_kernel", message: "Ready", obligations: [] },
        verification: { status: "verification_unavailable", certificate: null },
      } }) };
    }
    throw new Error(`Unexpected Studio verifier path ${path}`);
  };
  t.after(() => { globalThis.fetch = previousFetch; });
  const { studio, state } = studioHarness();
  studio.handleAction({ dataset: { creatorAction: "apply-formal-example", index: "0" } });
  const changed = await studio.handleAction({ dataset: { creatorAction: "check-formal-reference", index: "0" } });
  assert.equal(changed, true);
  assert.match(studio.render(state), /Lean kernel unavailable/);
  assert.doesNotMatch(studio.render(state), /Kernel-certified reference proof/);
});
