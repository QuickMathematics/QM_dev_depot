# QuickMaths

[![Full test suite](https://github.com/QuickMathematics/QuickMaths/actions/workflows/ci.yml/badge.svg)](https://github.com/QuickMathematics/QuickMaths/actions/workflows/ci.yml)
[![Live app](https://img.shields.io/badge/live-QuickMaths-123f35)](https://quickmathematics.github.io/QuickMaths/)

QuickMaths is a browser-first, local-first mastery learning app with prerequisite maps, educator-authored portable curricula, a substantial native Mathematics curriculum, installable Geography and Python Programming curricula (25 foundations lessons plus a three-lesson extension), structured proof/review workflows, lesson authoring, and an optional WebMCP tutor surface.

[![QuickMaths combined Mathematics and Geography mastery map](docs/assets/quickmaths-mastery-map.png)](https://quickmathematics.github.io/QuickMaths/#/map)

The public app runs entirely from GitHub Pages:

**https://quickmathematics.github.io/QuickMaths/**

No QuickMaths account, model API key, or paid application server is required. The complete local workspace autosaves in the browser and can be moved with full JSON backups or optional private-repository Workspace Storage.

WebMCP tools are available only when QuickMaths is open inside the ChatGPT or Codex in-app browser. External browsers retain the complete human app and receive a safe migration handoff: back up or configure private Workspace Storage first, then open QuickMaths in the in-app browser through the desktop link. The link carries only the public app URL and a concise manifest-first prompt—never credentials or workspace data. Every fresh visitor, learner, and educator starts with the single `get_agent_guide` command using `section: "summary"`; its unified manifest routes the correct workflow.

QuickMaths predates the challenge; the [WebMCP challenge document](WEBMCP_CHALLENGE.md#challenge-period-delta) separates the original application from the challenge-period extension and links the dated commit evidence.

## What is in the app

- Separate learner and educator profile paths with ownership-filtered educator views, browser autosave, full backups, and optional complete-workspace GitHub storage
- Public curriculum blueprints and privacy-warned private assignments with exact embedded-pack integrity, canonical maps copied into learner Plan mode, explicit lesson scope with prerequisite closure, learner rules, visible supplemental agent guidance, and assignment-progress isolation
- One combined mastery map for native Mathematics plus installable Geography, Python Programming, and future Lesson Depot subjects; Python adds formatted code prompts, structured trace tables, and deterministic pure-function assessments in a fresh disposable browser Worker using a self-hosted integrity-pinned runtime
- Persistent Plan mode with draggable layouts, desktop marquee/Ctrl selection, touch hold-selection, colored custom paths, and draggable free or connected comment nodes
- Enforced Hard path and guideline-only Open path
- Lesson-defined comprehensive mastery tests with generated variants, required work, proofs, trace tables, sandboxed Python functions, and review gates
- Human Lesson Studio for new subjects, new lessons, and reversible native-lesson improvements
- Federated Lesson Depot that discovers immutable packages from independent GitHub repositories, with optional in-app recommendations, flags, and comments
- Thirty-one WebMCP tools for visible navigation, tutoring, unified learner/educator guidance, machine-readable product manuals, on-demand lesson-authoring guidance, curriculum design and scoping, mastery-map planning, curriculum inspection, and single or batch human-controlled lesson staging
- Optional GitHub Bridge with task-start timestamps and selective local/GitHub merging in a required private writable repository

## Run the web app locally

```powershell
python -m http.server 8765 --directory docs
```

Open `http://localhost:8765/`.

The learner app is `docs/index.html`; the dedicated WebMCP agent workspace is `docs/agent-bridge.html`; and the mobile/storage walkthrough is `docs/bridge-guide.html`. The complete human manuals are `docs/QuickMaths-Student-Guide.pdf` and `docs/QuickMaths-Educator-Guide.pdf`.

## Local Git Bridge for Codex

The small `quickmaths/` Python tooling package is not a second learner app or the Programming curriculum. It remains solely for curriculum validation/export and the loopback Git Bridge.

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
python -m quickmaths.cli agent-bridge --repo https://github.com/YOUR-NAME/quickmaths-sync.git
```

Open the printed `127.0.0.1` URL in the ChatGPT or Codex in-app browser; an external browser cannot expose its WebMCP tools. The loopback server uses the computer's existing Git credentials and exposes only `learner-state.json` and `agent-state.json` from the selected data repository.

The local Bridge verifies repository privacy through GitHub when connecting and before each checkpoint write, using the existing host Git credential without sending it to the browser. Public repositories and unverifiable privacy checks stop writes. Checkpoint files must be regular Git files; symlinks and directories are rejected. After updating the Python package, restart any running local Bridge to apply these checks. See the [security review](docs/SECURITY_REVIEW.md) for the audit scope and regression coverage.

## Curriculum development

For authenticated Git pushes from this checkout, see [Direct GitHub publishing](docs/GITHUB_PUBLISHING.md).

The native Mathematics curriculum is authored in YAML under `content/math/algebra_foundations/`. The deterministic Geography source in `scripts/build_geography_web_curriculum.mjs` emits both the native Mathematics coordinate/geodesy bridge and the reproducible `PACK_GEOGRAPHY` fixture. Geography and Programming are published through the independent [`QuickMathematics/QM_Dev_Depot`](https://github.com/QuickMathematics/QM_Dev_Depot) registry so the production app dogfoods the same federated discovery path as community publishers.

Validate native YAML:

```powershell
python -m quickmaths.cli validate-content --strict-warnings
```

Regenerate the browser curriculum after native YAML changes:

```powershell
python scripts/export_web_curriculum.py
```

For portable custom lessons and native improvements, use the in-app Lesson Studio or the [Agent Lesson Authoring Guide](docs/CUSTOM_LESSON_SETS.md).

## Test

```powershell
python -m pytest -q
node --test docs/*.test.js
node --test community-worker/src/*.test.js
```

## Repository map

- `docs/` — the complete GitHub Pages app, WebMCP tools, guides, and browser tests
- `content/` — first-party curriculum sources
- `quickmaths/` — focused curriculum tooling and local Git Bridge
- `scripts/` — curriculum and Lesson Depot build/validation scripts
- `community-worker/` — stateless GitHub Community OAuth callback worker
- `tests/` — Python curriculum, grading, Depot, and Bridge tests
- `WEBMCP_CHALLENGE.md` — challenge architecture and demo walkthrough

## Storage and authorization boundaries

Browser autosave, GitHub Workspace Storage, federated lesson discovery, and Lesson Depot community authorization are separate systems. Workspace Storage uploads every local learner and educator profile, curriculum, attempt, review, installed pack, plan, and educator guidance to a dedicated private repository. Tokens are entered only in the app, are never committed, require Contents read/write, and should be restricted to that repository. Public registries cannot read learner state. Community authorization cannot read learner state either; its public actions are limited to GitHub Discussion reactions and comments.

Settings includes a human-only storage manager. Deleting a profile or clearing the complete workspace requires two confirmations; connected clearing deletes the current `learner-state.json` and `agent-state.json` files while preserving the configured connection and stored token, and the interface accurately warns that older Git commits may retain previous checkpoint contents. These destructive operations are not WebMCP tools.

Imported curricula start in a fresh assignment profile unless the curriculum's student name matches the selected learner profile name after whitespace and letter-case normalization. Only that explicit match reuses mastery for matching lesson IDs; the import confirmation and in-app tooltip explain the rule before records are attached.

QuickMaths is MIT licensed.

### Reviewing overlapping workspace updates

Start each Agent Bridge prompt with `begin_agent_task`. It records UTC time locally before reading the learner checkpoint. `publish_agent_checkpoint` pushes that original `task_started_at` and `base_learner_sha` with the completed `agent-state.json`; no separate start-time commit is needed. The learner app compares both local work and the current GitHub learner snapshot with that starting revision. Unchanged workspaces accept the update automatically. In manual mode, overlapping work opens a change checklist across lessons, mastery, feedback, profiles, curricula, tests, and maps. Individual node moves and notes can be combined, independent changes are preselected, and unchecked changes retain their starting values. Conflicting edits and deletions require an explicit choice. Saving rechecks both remote revisions and local content, uses a conditional GitHub write, and acknowledges the accepted agent checkpoint for other devices. Missing Git history falls back to an explicit two-way comparison. Timers and viewport changes alone do not cause a merge.

### Fields, branches, and storage management

QuickMaths now exposes Field → Branch → Lesson browsing and Studio branch suggestions while retaining compatible subject/subdomain file keys. The profile-adjacent status shows GitHub connection/save progress and time since the last successful save. Settings offers manual change review (default) or selective automatic merging with agent priority at conflicts; independent work survives from both copies. Missing history or invalid dependencies falls back to review. See the updated student, educator, authoring and Bridge guides.

The native curriculum and bundled packages now classify 128 lessons into 14 broad branches across Mathematics, Geography, and Programming. Canonical maps render nested field/branch bands. Older categories migrate to the optional lesson topic, while saved learning and plan data are preserved. See [the complete field/branch reference](docs/FIELDS_AND_BRANCHES.md).

## September lesson additions

The earlier Depot addition introduced three logarithm lessons and six trigonometry lessons, bringing the native Mathematics curriculum to 63 lessons at that stage. The current native branch contains 84 lessons, including the 21 Statistics and Probability lessons from Batches 12–18. The overlapping interval, polynomial-inequality and rational-inequality lessons retain their existing content and IDs. See [the batch provenance and trusted-function notes](docs/STATISTICS_BATCHES.md).

For learners with Programming Fundamentals with Python already installed, the [three-lesson Python extension](https://quickmathematics.github.io/QuickMaths/lesson-depot/lessons/python-extensions/1.0.0/lesson-set.json) adds type hints and dataclasses, iterators and generators, and recursion with trees and memoization. Download the JSON, then choose **Settings → Load lesson file**. This is an additive download; it keeps the original 25 lessons, code-grading improvements and saved work intact. It requires the existing foundations package and does not replace its published 1.2.0 release.

## Lesson media and Matplotlib

Lesson packs support images, video and audio in explanations, examples, applications and test questions. Studio attaches small files; folder publishing uploads larger media separately. Author in YAML/JSON, generate Matplotlib figures as PNG/SVG, and keep paths relative to the manifest. See the [media guide](docs/LESSON_MEDIA.md) and [geometry example](docs/examples/geometry-media/lesson-set.yaml).

Native Mathematics includes **Triangle area: base and perpendicular height**, with eight worked examples and 21 assessment scenarios. All sixteen Geometry lessons now include Matplotlib illustrations, covering triangle heights, coordinates, slope, lines, bearings, arcs, spherical coordinates, and trigonometry. These figures are embedded for offline use; run `python scripts/build_geometry_figures.py` and `python scripts/build_trigonometry_figures.py`, followed by `python scripts/export_web_curriculum.py` to rebuild them.

All 128 shipped lesson pages now have illustrations, including the 28 Programming lessons, new Statistics and Probability lessons, and optional Geography/Estimation packs. A content-matched library adds 130 hosted Matplotlib SVGs across 118 library lessons without reinstalling existing packs or changing saved progress. Figures load as they approach the viewport; hosted media is not guaranteed offline. Rebuild with `python -m scripts.build_lesson_illustrations`. See the [coverage report](docs/ILLUSTRATION_AUDIT.md).

Native Geometry mastery tests also include diagrams: coordinate and line graphs follow each randomized question's givens, with additional illustrations for bearings, arcs, spherical coordinates, triangle area and 73 spatial trigonometry scenarios. Restored drafts and saved results retain the original question's picture. The app draws these test diagrams locally; authored Matplotlib attachments remain available through the same lesson-media support.

```sh
pip install -e ".[media]"
quickmaths build-lesson docs/examples/geometry-media/lesson-set.yaml --output built-lesson
# Add --portable for one JSON file with up to 1 MB of embedded attachments.
```

## Local formal-learning build

Formal questions now connect the native proof workspace to reference-free WebMCP guidance and fresh Lean-certificate-gated assessment. Import `examples/formal-proof-lab.lesson-set.json` to try three candidate lessons. Pending/unavailable verification is not a learner failure. See [setup and trust boundaries](docs/FORMAL_LEARNING.md) and [the local release and validation notes](LOCAL_RELEASE.md). This source release does not bundle Lean or claim its reference candidates have been kernel-verified here.
