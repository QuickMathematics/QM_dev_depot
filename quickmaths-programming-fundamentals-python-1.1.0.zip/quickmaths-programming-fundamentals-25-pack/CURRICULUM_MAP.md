# Programming Fundamentals with Python — 25-Lesson Curriculum Map

This schema-2.0 QuickMaths lesson set contains 25 lessons and 250 fixed mastery questions. Lessons 1–15 are unchanged from version 1.0.0; lessons 16–25 form a second-stage beginner path.

## Progression

| # | Skill ID | Lesson | Internal prerequisites | Mathematics bridge |
|---:|---|---|---|---|
| 1 | `CUSTOM_PROG_001` | Algorithms and program execution | — | MATH_ARITH_001 (Integer operations) |
| 2 | `CUSTOM_PROG_002` | Values, variables, and data types | CUSTOM_PROG_001 | MATH_PREALG_001 (Variables and substitution) |
| 3 | `CUSTOM_PROG_003` | Expressions, assignment, and input/output | CUSTOM_PROG_002 | MATH_ARITH_002 (Order of operations) |
| 4 | `CUSTOM_PROG_004` | Boolean expressions and comparisons | CUSTOM_PROG_003 | — |
| 5 | `CUSTOM_PROG_005` | Conditional execution | CUSTOM_PROG_004 | — |
| 6 | `CUSTOM_PROG_006` | While loops and changing state | CUSTOM_PROG_005 | — |
| 7 | `CUSTOM_PROG_007` | For loops, ranges, and accumulators | CUSTOM_PROG_006 | — |
| 8 | `CUSTOM_PROG_008` | Functions, parameters, and return values | CUSTOM_PROG_007 | MATH_FUNC_001 (Function notation and representations) |
| 9 | `CUSTOM_PROG_009` | Strings and text processing | CUSTOM_PROG_008 | — |
| 10 | `CUSTOM_PROG_010` | Lists, indexing, and mutation | CUSTOM_PROG_009 | — |
| 11 | `CUSTOM_PROG_011` | Traversing and transforming collections | CUSTOM_PROG_010, CUSTOM_PROG_007 | — |
| 12 | `CUSTOM_PROG_012` | Dictionaries and structured data | CUSTOM_PROG_011 | — |
| 13 | `CUSTOM_PROG_013` | Debugging, testing, and edge cases | CUSTOM_PROG_008, CUSTOM_PROG_011 | — |
| 14 | `CUSTOM_PROG_014` | Problem decomposition and practical algorithms | CUSTOM_PROG_012, CUSTOM_PROG_013 | MATH_PREALG_005 (Translating words into expressions) |
| 15 | `CUSTOM_PROG_015` | Capstone: build a tested data-summary program | CUSTOM_PROG_014 | MATH_ARITH_005 (Decimals, percents, and conversions) |
| 16 | `CUSTOM_PROG_016` | Tuples, sets, and unpacking | CUSTOM_PROG_015 | MATH_GRAPH_001 (Coordinate plane) |
| 17 | `CUSTOM_PROG_017` | Nested collections and records | CUSTOM_PROG_016, CUSTOM_PROG_012 | — |
| 18 | `CUSTOM_PROG_018` | Files, paths, and context managers | CUSTOM_PROG_017, CUSTOM_PROG_009 | — |
| 19 | `CUSTOM_PROG_019` | Exceptions and defensive programming | CUSTOM_PROG_018, CUSTOM_PROG_013 | — |
| 20 | `CUSTOM_PROG_020` | Modules, imports, and the standard library | CUSTOM_PROG_019, CUSTOM_PROG_008 | — |
| 21 | `CUSTOM_PROG_021` | Comprehensions and data pipelines | CUSTOM_PROG_020, CUSTOM_PROG_011 | MATH_SEQ_001 (Arithmetic sequences) |
| 22 | `CUSTOM_PROG_022` | Classes, objects, and methods | CUSTOM_PROG_020, CUSTOM_PROG_012 | — |
| 23 | `CUSTOM_PROG_023` | Searching, sorting, and algorithmic efficiency | CUSTOM_PROG_021, CUSTOM_PROG_014 | MATH_EXP_002 (Exponential functions and percent change) |
| 24 | `CUSTOM_PROG_024` | Program architecture and command-line applications | CUSTOM_PROG_018, CUSTOM_PROG_019, CUSTOM_PROG_020, CUSTOM_PROG_022, CUSTOM_PROG_023 | — |
| 25 | `CUSTOM_PROG_025` | Capstone: build a persistent study tracker | CUSTOM_PROG_024 | — |

## Structure

Lessons 1–15 establish the core language and finish with a tested in-memory data-summary capstone. Lessons 16–25 extend that foundation into richer data structures, files, defensive programming, modules, comprehensions, classes, algorithmic efficiency, application architecture, and a persistent JSON-backed command-line capstone.

## Added Mathematics bridges

- `CUSTOM_PROG_016` uses `MATH_GRAPH_001` because coordinate pairs provide a natural fixed-record use case for tuples.
- `CUSTOM_PROG_021` uses `MATH_SEQ_001` because comprehensions and ranges apply rules across ordered sequences.
- `CUSTOM_PROG_023` uses `MATH_EXP_002` because comparing linear, logarithmic, quadratic, and exponential growth supports algorithm analysis.

These appear late enough that Hard-path learners have already completed a full beginner programming capstone. The earlier six Mathematics bridges remain unchanged.

## Assessment design

- Every lesson contains exactly 10 fixed questions.
- Lessons 1–24 each end with a required practical response saved for optional review.
- Lessons 15 and 25 are tutor-reviewed capstones that gate mastery through a rubric.
- Version 1.1.0 still uses only current schema-2.0 browser graders and work modes.
- Code traces retain `⏎` for line breaks and `↳` for indentation so prompts remain readable in the current text renderer.
