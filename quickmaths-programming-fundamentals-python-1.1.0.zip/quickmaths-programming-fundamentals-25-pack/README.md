# QuickMaths Programming Fundamentals with Python

Install `lesson-set.json` through **Settings → Load lesson set** or open it in Lesson Studio for inspection.

## Contents

- 25 Programming lessons
- 250 fixed mastery questions
- 9 explicit bridges to existing Mathematics skills
- 23 required code-writing exercises saved for optional review
- 2 tutor-reviewed capstone implementations
- separate Programming subject theme and mastery map

## Package identity

- Pack: `PACK_PROGRAMMING_FUNDAMENTALS`
- Subject: `SUBJECT_PROGRAMMING`
- Track: `TRACK_PROGRAMMING_FUNDAMENTALS`
- Version: `1.1.0`
- Author: QuickMaths
- Proposed content license: CC BY 4.0

## Compatibility

This version uses only the current schema-2.0 browser features:

- `multiple_choice`
- `exact_numeric`
- `numeric_with_tolerance`
- `capture_only`
- `rubric_check`

No new grader or work checker is required to install it.

## Preservation

Lessons 1–15 are unchanged from version 1.0.0. See `PRESERVATION_REPORT.txt` for per-lesson hashes.

## Important authoring boundary

`lesson-set.json` contains private expected answers, solution steps, and review criteria. Treat it as an author file, not as a learner worksheet or tutoring transcript.

## Files

- `lesson-set.json` — installable QuickMaths pack
- `metadata.json` — Lesson Depot metadata
- `new-lessons/` — individual review copies of lessons 16–25
- `CURRICULUM_MAP.md` — complete lesson graph and Mathematics bridges
- `UPGRADE_NOTES.md` — exact scope of the 1.1.0 expansion
- `PRESERVATION_REPORT.txt` — hashes proving lessons 1–15 were unchanged
- `PROGRAMMING_ENGINE_ENHANCEMENTS.md` — optional architecture for richer executable-code assessment
- `VALIDATION_REPORT.txt` — structural and semantic audit
- `CHECKSUMS.sha256` — integrity hashes
