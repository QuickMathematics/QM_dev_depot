# Upgrade Notes — 1.0.0 to 1.1.0

- Pack ID, subject ID, track ID, and all existing lesson/question IDs are unchanged.
- Lessons `CUSTOM_PROG_001` through `CUSTOM_PROG_015` are field-for-field identical to version 1.0.0.
- Ten lessons are appended as `CUSTOM_PROG_016` through `CUSTOM_PROG_025`.
- The track exit changes from `CUSTOM_PROG_015` to `CUSTOM_PROG_025`.
- `CUSTOM_PROG_016` depends on `CUSTOM_PROG_015`, so QuickMaths derives the new forward unlock without modifying lesson 15.
- The envelope and track descriptions now describe the 25-lesson scope.
- Version changes from `1.0.0` to `1.1.0`.

The current QuickMaths pack installer does not silently update an installed pack with the same ID. Review the app's chosen update/removal workflow before distributing this as an upgrade to learners with existing progress.
