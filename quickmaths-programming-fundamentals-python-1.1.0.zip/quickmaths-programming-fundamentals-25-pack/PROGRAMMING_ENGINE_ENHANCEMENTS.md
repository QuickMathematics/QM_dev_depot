# Optional Programming-Assessment Enhancements

Programming Fundamentals with Python 1.1.0 is valid without these changes. It uses objective final-answer graders plus saved `capture_only` code and one `rubric_check` capstone. The following additions would support a later version in which learners receive immediate, trustworthy feedback on actual programs.

## 1. Structured prompt blocks

### Problem

The current question renderer places the entire prompt inside a heading. HTML collapses ordinary newlines and indentation, which makes Python blocks difficult to read.

### Proposed schema

```json
{
  "prompt": "Trace the program.",
  "prompt_blocks": [
    {"type": "text", "text": "Trace the program and enter the printed value."},
    {
      "type": "code",
      "language": "python",
      "text": "total = 0\nfor n in range(1, 5):\n    total += n\nprint(total)"
    }
  ]
}
```

`prompt` remains required as a plain-text accessibility and compatibility fallback. `prompt_blocks` is optional and declarative.

### Rendering

- Render text blocks as escaped text.
- Render code blocks as `<pre><code>` with `white-space: pre`, horizontal scrolling, and a visible language label.
- Never interpret lesson-supplied HTML.
- Preserve tabs by normalizing them to four spaces.
- Cap each block and the aggregate prompt length.
- Include code text in accessible names or an adjacent screen-reader description.

This changes presentation only; it does not execute uploaded code.

## 2. `python_program` final-answer grader

### Goal

Grade learner-authored Python against declarative examples and tests without executing package-authored scripts.

### Proposed problem shape

```json
{
  "answer_type": "code",
  "grading_method": "python_program",
  "program_spec": {
    "runtime": "python_subset_v1",
    "entrypoint": {
      "kind": "function",
      "name": "is_even",
      "parameters": [
        {"name": "number", "type": "int"}
      ],
      "return_type": "bool"
    },
    "tests": [
      {"id": "even", "args": [8], "expected_return": true, "visibility": "example"},
      {"id": "odd", "args": [7], "expected_return": false, "visibility": "after_submission"},
      {"id": "zero", "args": [0], "expected_return": true, "visibility": "hidden"}
    ],
    "limits": {
      "wall_time_ms": 750,
      "step_limit": 100000,
      "memory_mb": 32,
      "stdout_chars": 4000
    },
    "policy": {
      "allowed_builtins": ["abs", "all", "any", "enumerate", "len", "max", "min", "range", "round", "sorted", "sum"],
      "imports": [],
      "network": false,
      "storage": false,
      "clock": false,
      "randomness": false
    }
  }
}
```

The lesson file supplies data: function signature, typed arguments, expected returns, and limits. It supplies no executable test harness.

### Execution boundary

Run learner code in a disposable Worker or similarly isolated runtime:

1. Create a fresh sandbox for every submission.
2. Disable network, DOM, browser storage, filesystem, process spawning, imports, dynamic evaluation, and access to host objects.
3. Enforce wall-time, instruction/step, memory, recursion, and output limits.
4. Terminate the sandbox after grading.
5. Serialize arguments and results through a narrow JSON-compatible boundary.
6. Reject unsupported syntax before execution.
7. Never reuse mutable state between tests.
8. Report syntax errors, runtime errors, timeouts, and wrong results as distinct outcomes.

A small explicitly documented Python subset is safer and easier to make deterministic than silently claiming full CPython support. Pyodide could be used only if it is kept in a locked Worker with the same capability restrictions and tests demonstrate that escape routes are unavailable.

### Grading result

```json
{
  "status": "incorrect",
  "score": 0.67,
  "passed": 2,
  "total": 3,
  "tests": [
    {"id": "even", "status": "passed"},
    {"id": "odd", "status": "passed"},
    {"id": "zero", "status": "failed", "message": "Expected true; received false"}
  ],
  "messages": ["2 of 3 tests passed."]
}
```

Before submission, expose only tests whose visibility is `example`. After submission, expose `after_submission`. Never reveal hidden inputs or expected values through learner-facing tools.

### Validator requirements

- Stable unique test IDs.
- JSON-compatible argument and expected-result values.
- Supported entrypoint kind, runtime, and declared types.
- At least one test and a conservative maximum, such as 30.
- Positive limits within application caps.
- No package-supplied source code, expressions, callbacks, imports, URLs, or test scripts.
- No nondeterministic capabilities unless a later runtime explicitly supports seeded randomness.

## 3. `code_trace_steps` work checker

### Goal

Check whether a learner can trace state changes without executing arbitrary lesson-supplied code.

### Declarative trace specification

```json
{
  "work": {
    "mode": "code_trace_steps",
    "prompt": "Complete the trace table.",
    "trace_spec": {
      "language": "python",
      "display_code": "x = 2\ny = x + 3\nx = 9\nprint(y)",
      "columns": ["step", "x", "y", "output"],
      "expected_rows": [
        {"step": 1, "x": "2", "y": null, "output": ""},
        {"step": 2, "x": "2", "y": "5", "output": ""},
        {"step": 3, "x": "9", "y": "5", "output": ""},
        {"step": 4, "x": "9", "y": "5", "output": "5"}
      ],
      "comparison": {
        "trim_strings": true,
        "numeric_equivalence": true,
        "blank_equals_null": true
      }
    }
  }
}
```

The app displays `display_code`, but grades only against the declarative expected rows. It does not execute the uploaded code.

### Learner response

Store the trace in `structured_work_json`:

```json
{
  "rows": [
    {"step": 1, "x": "2", "y": "", "output": ""},
    {"step": 2, "x": "2", "y": "5", "output": ""},
    {"step": 3, "x": "9", "y": "5", "output": ""},
    {"step": 4, "x": "9", "y": "5", "output": "5"}
  ]
}
```

### Checker behaviour

- Require the authored columns and row count.
- Compare stable step IDs rather than only visual position.
- Distinguish a missing row, wrong variable value, unexpected mutation, and wrong output.
- Allow an author-selected subset of variables to reduce busywork.
- Normalize numeric forms conservatively; do not treat arbitrary expressions as equivalent unless explicitly enabled.
- Save per-cell diagnostics so tutors can see where the trace diverged.
- Keep the separate final answer grader independent from the trace check.

## 4. Optional `python_ast_rules`

Passing examples alone does not always demonstrate the requested technique. An optional declarative static-policy block can enforce beginner constraints:

```json
{
  "ast_rules": {
    "required": ["function_definition", "return_statement"],
    "forbidden": ["import_statement", "global_statement", "eval_call"],
    "max_loop_nesting": 2,
    "max_function_length": 40
  }
}
```

Rules should inspect a parsed AST from the supported subset. They must never be implemented by fragile substring matching.

## Recommended rollout

1. Add structured prompt blocks first; they improve the existing pack immediately.
2. Add `code_trace_steps` because it is deterministic and executes no package code.
3. Add `python_program` only after the sandbox threat model and escape tests are complete.
4. Upgrade selected practical questions in lessons 2–25 while preserving IDs only if completed learner progress is intentionally migrated; otherwise publish a new pack version with stable new question IDs.
5. Keep rubric review for capstones even when tests pass, because tests establish behaviour but do not fully assess decomposition, clarity, or explanation.

## Version 1.1.0 expansion targets

The same future grader would be especially valuable for lessons 18–25: file parsing, narrow exception handling, module boundaries, comprehensions, classes, search algorithms, command processing, JSON persistence, and the final application capstone. File tests must use a sandbox-owned virtual filesystem or declarative in-memory fixtures rather than host filesystem access.
