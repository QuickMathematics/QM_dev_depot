# Package Inventory

## Direct-install files

- `lesson-set.json` — schema-2.0 QuickMaths lesson set with all 25 lessons
- `metadata.json` — proposed Lesson Depot metadata for version 1.1.0

## Review files

- `new-lessons/CUSTOM_PROG_016.json` through `CUSTOM_PROG_025.json`
- `CURRICULUM_MAP.md`
- `UPGRADE_NOTES.md`
- `PRESERVATION_REPORT.txt`
- `PROGRAMMING_ENGINE_ENHANCEMENTS.md`
- `VALIDATION_REPORT.txt`
- `validation-summary.json`
- `lesson-set-1.0.0-to-1.1.0.patch`
- `CHECKSUMS.sha256`

## Depot-ready layout

- `depot-layout/lessons/programming-fundamentals-python/1.1.0/lesson-set.json`
- `depot-layout/lessons/programming-fundamentals-python/1.1.0/metadata.json`

The Depot-layout copies are byte-identical to the direct-install files.
