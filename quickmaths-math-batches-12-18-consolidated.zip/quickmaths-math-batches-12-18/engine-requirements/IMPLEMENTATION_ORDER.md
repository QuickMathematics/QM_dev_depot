# Trusted numerical helper implementation order

1. Batch 16: `normal_cdf(z)`, `inverse_normal_cdf(p)`, `t_cdf(t, df)`.
2. Batch 17: `chi_square_cdf(x, df)` and stable right-tail `chi_square_sf(x, df)`.
3. Batch 18: stable right-tail `f_sf(x, df1, df2)`.

All helpers belong only to the trusted first-party native expression evaluator in Python and the browser. Uploaded lesson packages remain fixed data.
