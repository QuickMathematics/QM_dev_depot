# Batch 12 — Statistics with media

Lessons: MATH_STAT_001 center/spread/outliers; MATH_STAT_002 distributions/histograms/box plots; MATH_STAT_003 scatter plots/correlation/residuals. Historical authored scenario counts: 15, 16, 16.
