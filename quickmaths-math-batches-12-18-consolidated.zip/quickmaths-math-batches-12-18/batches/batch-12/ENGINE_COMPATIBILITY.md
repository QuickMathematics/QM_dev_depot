# Engine compatibility

No new grader or work-checker functionality is required. Batch 12 uses existing exact_numeric, numeric_with_tolerance, multiple_choice, equation_solution, procedural_steps, capture_only, and native image media. Matplotlib is author-time only.
