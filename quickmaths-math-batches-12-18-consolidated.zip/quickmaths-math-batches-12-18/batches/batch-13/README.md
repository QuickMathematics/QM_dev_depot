# Batch 13 — Probability

MATH_PROB_001 probability foundations; MATH_PROB_002 compound/conditional probability; MATH_PROB_003 discrete random variables and expected value.
