# Engine compatibility

No new QuickMaths grader, generator, or media-runtime feature is required. Uses exact_numeric, multiple_choice, capture_only, native int/choice variables and static author-time media.
