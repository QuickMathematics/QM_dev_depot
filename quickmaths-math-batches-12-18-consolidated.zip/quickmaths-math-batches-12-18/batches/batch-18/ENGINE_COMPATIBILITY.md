# Stable F-distribution right tail — Batch 18

Required trusted-native function: `f_sf(x, df1, df2)=P(F_df1,df2 >= x)`. Validate finite x>=0 and df1,df2>0; fractional df valid. Calculate the upper tail directly via the regularized incomplete beta identity z=df2/(df2+df1*x), f_sf=I_z(df2/2,df1/2). Use lgamma plus a modified-Lentz beta continued fraction, symmetry for numerical conditioning, maximum 300 iterations, relative tolerance <=1e-14, deterministic domain/convergence errors, and parity tests in Python/browser. Add only to trusted native expression allowlists. Uploaded lesson packages remain fixed data. Inverse F is not required.

Batch 18 also assumes Batch16 t_cdf and Batch17 chi_square_sf are implemented. It needs no new grader; interval_set is reused for bootstrap intervals.
