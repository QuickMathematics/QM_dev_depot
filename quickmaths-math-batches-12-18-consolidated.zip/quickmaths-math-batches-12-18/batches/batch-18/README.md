# Batch 18 — ANOVA, multiple regression, and resampling
