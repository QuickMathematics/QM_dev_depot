# Trusted distribution functions — Batch 16

Required in both trusted native evaluators:

- `normal_cdf(z) = P(Z <= z)` for finite real z.
- `inverse_normal_cdf(p)` for 0 < p < 1, supporting at least 1e-6..1-1e-6.
- `t_cdf(t, df) = P(T_df <= t)` for finite t and positive degrees of freedom.

Implement dependency-free matching Python/browser algorithms, reject invalid domains rather than coercing, preserve monotonicity and symmetry, and test numerical parity. These functions are trusted first-party template helpers only; uploaded packages remain fixed data. `inverse_t_cdf` is not required by Batches 16–18.
