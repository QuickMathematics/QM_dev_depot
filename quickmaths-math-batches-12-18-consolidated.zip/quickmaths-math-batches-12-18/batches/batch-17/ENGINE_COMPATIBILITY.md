# Chi-square trusted distribution helpers — Batch 17

Required trusted-native functions:
- `chi_square_cdf(x, df) = P(ChiSquare_df <= x)`
- `chi_square_sf(x, df) = P(ChiSquare_df >= x)` calculated directly in the upper tail.

Require finite x>=0 and df>0 (fractional df mathematically valid), return finite probabilities in [0,1], preserve monotonicity and cdf+sf≈1, and reject invalid domains. Implement using regularized incomplete gamma: P(df/2,x/2) and Q(df/2,x/2), with a lower-gamma series for small x and a modified-Lentz upper-gamma continued fraction for large x. Use lgamma, max 300 iterations, relative convergence <=1e-14. Add both functions to Python/browser trusted allowlists. Uploaded packages remain fixed data. Batch17 calls only chi_square_sf.
