# Batch 17 — Categorical and regression inference
