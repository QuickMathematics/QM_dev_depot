# Engine compatibility

No new engine functionality required. Uses existing numeric/multiple-choice grading and capture_only. Normal-tail questions are fixed or use supplied areas; no runtime distribution CDF required.
