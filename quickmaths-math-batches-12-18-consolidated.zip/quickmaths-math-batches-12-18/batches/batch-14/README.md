# Batch 14 — Counting, binomial and normal models
