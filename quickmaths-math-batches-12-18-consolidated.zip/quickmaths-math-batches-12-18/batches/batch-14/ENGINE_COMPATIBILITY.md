# Engine compatibility

No new engine functionality required. Uses exact_numeric, numeric_with_tolerance, multiple_choice, int/choice generation and capture_only. Normal CDF is intentionally not required in this batch.
