# QuickMaths Mathematics — consolidated Batches 12 through 18

This is a single source handoff containing the reconstructed Mathematics lesson work from **Batches 12–18**.

## What is inside

- `batches/batch-12/` … `batches/batch-18/` — each batch kept separately with its lesson YAMLs, engine compatibility notes, feature requests where applicable, and integration summaries.
- `combined/lessons/` — one flat copy of all 21 lessons for convenient local application.
- `combined/engine/` — the cumulative engine contracts plus machine-readable numerical reference vectors.
- `engine-requirements/` — implementation order and per-batch feature requirements.
- `BATCH_INDEX.md` — human-readable lesson/batch index.
- `MANIFEST.json` — machine-readable batch and lesson manifest.
- `MEDIA_PIPELINES.md` — historical media/illustration architecture summary.
- `VALIDATION_REPORT.txt` and `VALIDATION_SUMMARY.json` — reconstruction validation results.
- `reconstruction/` — the scripts used to rebuild the bundle from the earlier authored conversation state.
- `CHECKSUMS.sha256` — SHA-256 for every file in the bundle except the checksum file itself.

## Trusted engine features introduced by these batches

Batches 12–15 use the existing native lesson engine. Later inference batches require these trusted first-party expression helpers, in order:

```text
Batch 16
  normal_cdf(z)
  inverse_normal_cdf(p)
  t_cdf(t, df)

Batch 17
  chi_square_cdf(x, df)
  chi_square_sf(x, df)

Batch 18
  f_sf(x, df1, df2)
```

These helpers belong only to trusted repository-authored native generation in Python and the browser. They do **not** grant uploaded/community lessons executable expressions.

See `combined/ENGINE_REQUIREMENTS.md`, the per-batch feature documents, and the JSON acceptance vectors before applying the inference batches.

## Provenance

The original standalone ZIP bytes created earlier in the conversation were not mounted in the current execution environment. This bundle is therefore a **source reconstruction**, not a byte-for-byte concatenation of those historical ZIP files. See `RECONSTRUCTION_NOTICE.md` for the exact scope of that caveat.

Nothing in this archive writes to GitHub.
