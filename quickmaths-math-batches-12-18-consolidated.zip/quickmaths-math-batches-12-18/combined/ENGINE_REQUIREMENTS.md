# Combined engine requirements — Batches 12–18

## Existing native capabilities used throughout

- `exact_numeric`, `numeric_with_tolerance`, `multiple_choice`; selected batches also use already-designed semantic graders such as interval-set where present in the reconstructed YAML.
- `capture_only` and existing structured/procedural work modes where authored.
- trusted native `int`, `choice`, and arithmetic derived expressions.
- recursively rendered prompts, answers, explanations, work metadata, and options.
- author-time / hosted illustration pipelines; learner runtime receives static media or hosted illustration metadata.

## New trusted functions, in implementation order

### Batch 16

```text
normal_cdf(z)
inverse_normal_cdf(p)
t_cdf(t, df)
```

These are trusted first-party expression helpers only. `normal_cdf` and `t_cdf` are lower-tail functions. `inverse_normal_cdf` requires `0 < p < 1`. An inverse-t helper is not required.

### Batch 17

```text
chi_square_cdf(x, df)
chi_square_sf(x, df)
```

`x >= 0`, `df > 0`. The survival function should calculate the upper tail stably via the regularized upper incomplete gamma rather than naive `1-cdf`.

### Batch 18

```text
f_sf(x, df1, df2)
```

`x >= 0`, `df1 > 0`, `df2 > 0`. Use a stable regularized incomplete-beta formulation for the upper tail. No inverse-F helper is required.

## Security boundary

Do not expand uploaded/community lesson packages into executable expression sources. These helpers belong only to trusted repository-authored native generation in the Python exporter/validator and browser-native retake generator.

See the per-batch feature documents and JSON acceptance vectors for exact domain, numerical, and parity requirements.
