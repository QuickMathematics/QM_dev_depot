# Consolidated curriculum extension — Batches 12–18

This file is a navigation aid, not a replacement for QuickMaths `track.yaml`.

```text
Statistics foundations
MATH_STAT_001 → MATH_STAT_002 → MATH_STAT_003

Probability foundations
MATH_PROB_001 → MATH_PROB_002 → MATH_PROB_003
                      ↓
                 MATH_PROB_004 → MATH_PROB_005
                                      ↓
Normal / sampling / introductory inference
MATH_STAT_004 → MATH_STAT_005 → MATH_STAT_006 → MATH_STAT_007

Advanced distribution inference
MATH_STAT_008 → MATH_STAT_009 → MATH_STAT_010

Categorical / regression inference
MATH_STAT_011 → MATH_STAT_012 → MATH_STAT_013

General linear / simulation extension
MATH_STAT_014 → MATH_STAT_015 → MATH_STAT_016
```

The actual reconstructed prerequisite lists remain authoritative and are stored inside each YAML. Several later lessons have multiple prerequisites, so the simplified arrows above are intentionally only a reading order.
