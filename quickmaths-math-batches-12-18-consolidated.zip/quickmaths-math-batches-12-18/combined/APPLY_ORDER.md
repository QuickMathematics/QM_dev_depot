# Apply order

1. Start from the QuickMaths repository baseline used by the lesson work.
2. Integrate Batches 12–15 in order. They require no new trusted distribution functions.
3. Implement and test Batch 16 helpers: `normal_cdf`, `inverse_normal_cdf`, `t_cdf`.
4. Integrate Batch 16 lessons.
5. Implement and test Batch 17 helpers: `chi_square_cdf`, `chi_square_sf`.
6. Integrate Batch 17 lessons.
7. Implement and test Batch 18 helper: `f_sf`.
8. Integrate Batch 18 lessons and hosted-illustration changes.
9. Re-run native validation, curriculum export, taxonomy/branch generators, hosted illustration build, Python tests, and browser tests.

Because this is a reconstruction bundle rather than the original standalone ZIP bytes, use each batch's integration summary and engine notes as the source of intent, then let the current repository test suite resolve any line-level drift.
