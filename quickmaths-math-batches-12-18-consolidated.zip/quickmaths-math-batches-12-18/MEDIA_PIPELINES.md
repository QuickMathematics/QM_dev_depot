# Media / illustration pipeline summary

- **Batch 12:** original package used deterministic author-time Matplotlib statistics figures.
- **Batch 13:** original package used deterministic probability SVG figures.
- **Batch 14:** original package used counting/binomial/normal-model figures.
- **Batch 15:** original package used statistical-inference figures.
- **Batches 16–17:** original standalone packages contained compact/reused inference media alongside the lesson YAMLs.
- **Batch 18:** intentionally moved new teaching figures into QuickMaths' hosted content-fingerprinted illustration library to avoid exhausting the native embedded-media ceiling.

The current combined reconstruction focuses on lesson source + engine/integration requirements. Historical media bytes from the unavailable prior standalone ZIPs are not claimed to be reproduced unless a batch directory explicitly contains them.
