# Batch index

This bundle contains 21 Mathematics lessons reconstructed from Batches 12 through 18. See `RECONSTRUCTION_NOTICE.md` for provenance.

## Batch 12 — Statistics foundations

Engine: **No new engine feature**

- `MATH_STAT_001` — Center, spread, and outliers — 15 scenarios
- `MATH_STAT_002` — Distributions, histograms, and box plots — 16 scenarios
- `MATH_STAT_003` — Scatter plots, correlation, and residuals — 16 scenarios

## Batch 13 — Probability foundations

Engine: **No new engine feature**

- `MATH_PROB_001` — Probability models and sample spaces — 12 scenarios
- `MATH_PROB_002` — Compound and conditional probability — 13 scenarios
- `MATH_PROB_003` — Discrete random variables and expected value — 13 scenarios

## Batch 14 — Counting, binomial, and normal models

Engine: **No new engine feature**

- `MATH_PROB_004` — Counting principles, permutations, and combinations — 13 scenarios
- `MATH_PROB_005` — Binomial probability distributions — 13 scenarios
- `MATH_STAT_004` — Normal distributions and z-scores — 13 scenarios

## Batch 15 — Sampling and introductory inference

Engine: **No new engine feature**

- `MATH_STAT_005` — Sampling distributions and standard error — 13 scenarios
- `MATH_STAT_006` — Confidence intervals and margin of error — 13 scenarios
- `MATH_STAT_007` — Hypothesis tests, p-values, and power — 13 scenarios

## Batch 16 — Advanced distribution-based inference

Engine: **normal_cdf, inverse_normal_cdf, t_cdf**

- `MATH_STAT_008` — Student’s t distributions and one-sample t inference — 13 scenarios
- `MATH_STAT_009` — Comparing two means and matched pairs — 13 scenarios
- `MATH_STAT_010` — Inference for one and two population proportions — 13 scenarios

## Batch 17 — Categorical and regression inference

Engine: **chi_square_cdf, chi_square_sf (+ Batch 16 t_cdf)**

- `MATH_STAT_011` — Chi-square goodness-of-fit tests — 13 scenarios
- `MATH_STAT_012` — Chi-square tests for two-way tables — 13 scenarios
- `MATH_STAT_013` — Inference for a linear regression slope — 13 scenarios

## Batch 18 — ANOVA, multiple regression, and resampling

Engine: **f_sf (+ earlier distribution helpers)**

- `MATH_STAT_014` — One-way ANOVA and F tests — 13 scenarios
- `MATH_STAT_015` — Multiple linear regression and partial effects — 13 scenarios
- `MATH_STAT_016` — Bootstrap and randomization-based inference — 13 scenarios

